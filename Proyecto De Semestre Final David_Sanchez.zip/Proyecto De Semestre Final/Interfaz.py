import tkinter

# Crea la ventana y la asocia a la variable v

v = tkinter.Tk()
v.title("Game")


#Funcion para volver al menu Mpa1   

def backMenuMpa1():
    """
    """
    v2.destroy()
    v.deiconify()



#Funcion para avanzar al siguiente nivel 2 

def NextLevel2():
    """
    """
    v2.destroy()
    NuevaVentanaMpa2()
    

#######################################


#######################################
#Funcion para la puntuacion del player 1 del Mpa1

def Puntuacion_1P():
    """
    """
    global v2, P1P
    Puntuacion = tkinter.Label(v2)
    Puntuacion.config(text=""+str(P1P),width=5,fg="white",bg="black",font="ARIALBLACK")
    Puntuacion.place(x=550, y=100)
    if(P1P >= 0):
        P1P = P1P+10
        
    d1.after(900,Puntuacion_1P)
P1P=0
#######################################


#######################################
#Funcion para la puntuacion del player 2 del Mpa1

def Puntuacion_2P():
    """
    """
    global v2, P2P
    Puntuacion2 = tkinter.Label(v2)
    Puntuacion2.config(text=""+str(P2P),width=5,fg="white",bg="black",font="ARIALBLACK")
    Puntuacion2.place(x=1240, y=100)
    if(P2P >= 0):
        P2P = P2P+10
        
    d1.after(900,Puntuacion_2P)
P2P=0
#######################################



#######################################
#Funcion para la velocidad del player 1 del Mpa1

def Velocidad_1P():
    """
    """
    global v2, V1P
    Velocidad = tkinter.Label(v2)
    Velocidad.config(text=""+str(V1P),width=5,fg="white",bg="black",font="ARIALBLACK")
    Velocidad.place(x=575, y=300)
    if(V1P >= 0):
        V1P = V1P + 1
        
    d1.after(500,Velocidad_1P)
V1P = 0
#######################################

#######################################
#Funcion para la velocidad del player 2 del Mpa1

def Velocidad_2P():
    """
    """
    global v2, V2P
    Velocidad2 = tkinter.Label(v2)
    Velocidad2.config(text=""+str(V2P),width=5,fg="white",bg="black",font="ARIALBLACK")
    Velocidad2.place(x=1260, y=300)
    if(V2P >= 0):
        V2P = V2P + 1
        
    d1.after(500,Velocidad_2P)
V2P = 0
#######################################


#Funcion para el combustible del player 1 del Mpa1

def fuel():
    """
    """
    global v2, CF1
    Fuel = tkinter.Label(v2)
    Fuel.config(text=""+str(CF1),width=5,fg="white",bg="black",font="ARIALBLACK")
    Fuel.place(x=570, y=560)
    if(CF1 > 0):
        CF1 = CF1-1
        
    d1.after(780,fuel)
CF1=100
#######################################

#######################################
#Funcion para el combustible del playes 2 del Mpa1

def fuel2():
    """
    """
    global v2, CF2
    Fuel2 = tkinter.Label(v2)
    Fuel2.config(text=""+str(CF2),width=5,fg="white",bg="black",font="ARIALBLACK")
    Fuel2.place(x=1256, y=560)
    if(CF2 > 0):
        CF2 = CF2-1
        
    d1.after(780,fuel2)
CF2=100


#######################################
#Funcion para la puntuacion del player 1 del Mpa2

def Puntuacion_1PMpa2():
    """
    """
    global v3, P1PMpa2
    PuntuacionMpa2 = tkinter.Label(v3)
    PuntuacionMpa2.config(text=""+str(P1PMpa2),width=5,fg="white",bg="black",font="ARIALBLACK")
    PuntuacionMpa2.place(x=550, y=100)
    if(P1PMpa2 >= 0):
        P1PMpa2 = P1PMpa2 + 10
        
    d2.after(500,Puntuacion_1PMpa2)
P1PMpa2=0
#######################################


#######################################
#Funcion para la puntuacion del player 2 del Mpa2

def Puntuacion_2PMpa2():
    """
    """
    global v3, P2PMpa2
    Puntuacion2Mpa2 = tkinter.Label(v3)
    Puntuacion2Mpa2.config(text=""+str(P2PMpa2),width=5,fg="white",bg="black",font="ARIALBLACK")
    Puntuacion2Mpa2.place(x=1240, y=100)
    if(P2PMpa2 >= 0):
        P2PMpa2 = P2PMpa2 + 10
        
    d2.after(500,Puntuacion_2PMpa2)
P2PMpa2=0
#######################################


#######################################
#Funcion para la velocidad del player 1 del Mpa2

def Velocidad_1PMpa2():
    """
    """
    global v3, V1PMpa2
    VelocidadMpa2 = tkinter.Label(v3)
    VelocidadMpa2.config(text=""+str(V1PMpa2),width=5,fg="white",bg="black",font="ARIALBLACK")
    VelocidadMpa2.place(x=575, y=300)
    if(V1PMpa2 >= 0):
        V1PMpa2 = V1PMpa2 + 1
        
    d2.after(300,Velocidad_1PMpa2)
V1PMpa2 = 0

#######################################
#Funcion para la velocidad del player 2 del Mpa2

def Velocidad_2PMpa2():
    """
    """
    global v3, V2PMpa2
    Velocidad2Mpa2 = tkinter.Label(v3)
    Velocidad2Mpa2.config(text=""+str(V2PMpa2),width=5,fg="white",bg="black",font="ARIALBLACK")
    Velocidad2Mpa2.place(x=1260, y=300)
    if(V2PMpa2 >= 0):
        V2PMpa2 = V2PMpa2 + 1
        
    d2.after(300,Velocidad_2PMpa2)
V2PMpa2 = 0

#######################################
#Funcion para el combustible del player 1 del Mpa2

def fuelMpa2():
    """
    """
    global v3, CF1Mpa2
    FuelMpa2 = tkinter.Label(v3)
    FuelMpa2.config(text=""+str(CF1Mpa2),width=5,fg="white",bg="black",font="ARIALBLACK")
    FuelMpa2.place(x=570, y=560)
    if(CF1Mpa2 > 0):
        CF1Mpa2 = CF1Mpa2-1
        
    d2.after(380,fuelMpa2)
CF1Mpa2=100


#######################################
#Funcion para el combustible del player 2 del Mpa2

def fuel2Mpa2():
    """
    """
    global v3, CF2Mpa2
    Fuel2Mpa2 = tkinter.Label(v3)
    Fuel2Mpa2.config(text=""+str(CF2Mpa2),width=5,fg="white",bg="black",font="ARIALBLACK")
    Fuel2Mpa2.place(x=1256, y=560)
    if(CF2Mpa2 > 0):
        CF2Mpa2 = CF2Mpa2-1
        
    d2.after(380,fuel2Mpa2)
CF2Mpa2=100




#######################################
#Funcion para la puntuacion del player 1 del Mpa3

def Puntuacion_1PMpa3():
    """
    """
    global v4, P1PMpa3
    PuntuacionMpa3 = tkinter.Label(v4)
    PuntuacionMpa3.config(text=""+str(P1PMpa3),width=5,fg="white",bg="black",font="ARIALBLACK")
    PuntuacionMpa3.place(x=550, y=100)
    if(P1PMpa3 >= 0):
        P1PMpa3 = P1PMpa3 + 10
        
    d3.after(500,Puntuacion_1PMpa3)
P1PMpa3=0
#######################################


#######################################
#Funcion para la puntuacion del player 2 del Mpa3

def Puntuacion_2PMpa3():
    """
    """
    global v4, P2PMpa3
    Puntuacion2Mpa3 = tkinter.Label(v4)
    Puntuacion2Mpa3.config(text=""+str(P2PMpa3),width=5,fg="white",bg="black",font="ARIALBLACK")
    Puntuacion2Mpa3.place(x=1240, y=100)
    if(P2PMpa3 >= 0):
        P2PMpa3 = P2PMpa3 + 10
        
    d3.after(500,Puntuacion_2PMpa3)
P2PMpa3=0
#######################################


#######################################
#Funcion para la velocidad del player 1 del Mpa3

def Velocidad_1PMpa3():
    """
    """
    global v4, V1PMpa3
    VelocidadMpa3 = tkinter.Label(v4)
    VelocidadMpa3.config(text=""+str(V1PMpa3),width=5,fg="white",bg="black",font="ARIALBLACK")
    VelocidadMpa3.place(x=575, y=300)
    if(V1PMpa3 >= 0):
        V1PMpa3 = V1PMpa3 + 1
        
    d3.after(150,Velocidad_1PMpa3)
V1PMpa3 = 0


#######################################
#Funcion para la velocidad del player 2 del Mpa3

def Velocidad_2PMpa3():
    """
    """
    global v4, V2PMpa3
    Velocidad2Mpa3 = tkinter.Label(v4)
    Velocidad2Mpa3.config(text=""+str(V2PMpa3),width=5,fg="white",bg="black",font="ARIALBLACK")
    Velocidad2Mpa3.place(x=1260, y=300)
    if(V2PMpa3 >= 0):
        V2PMpa3 = V2PMpa3 + 1
        
    d3.after(150,Velocidad_2PMpa3)
V2PMpa3 = 0


#######################################
#Funcion para el combustible del player 1 del Mpa3

def fuelMpa3():
    """
    """
    global v4, CF1Mpa3
    FuelMpa3 = tkinter.Label(v4)
    FuelMpa3.config(text=""+str(CF1Mpa3),width=5,fg="white",bg="black",font="ARIALBLACK")
    FuelMpa3.place(x=570, y=560)
    if(CF1Mpa3 > 0):
        CF1Mpa3 = CF1Mpa3-1
        
    d3.after(340,fuelMpa3)
CF1Mpa3=100


#######################################
#Funcion para el combustible del player 2 del Mpa3

def fuel2Mpa3():
    """
    """
    global v4, CF2Mpa3
    Fuel2Mpa3 = tkinter.Label(v4)
    Fuel2Mpa3.config(text=""+str(CF2Mpa3),width=5,fg="white",bg="black",font="ARIALBLACK")
    Fuel2Mpa3.place(x=1256, y=560)
    if(CF2Mpa3 > 0):
        CF2Mpa3 = CF2Mpa3 - 1
        
    d3.after(340,fuel2Mpa3)
CF2Mpa3=100


###########################################""""""""""""##############################################################################


#######################################
#Funcion para la puntuacion del player 1 del Mpa4

def Puntuacion_1PMpa4():
    """
    """
    global v5, P1PMpa4
    PuntuacionMpa4 = tkinter.Label(v5)
    PuntuacionMpa4.config(text=""+str(P1PMpa4),width=5,fg="white",bg="black",font="ARIALBLACK")
    PuntuacionMpa4.place(x=550, y=100)
    if(P1PMpa4 >= 0):
        P1PMpa4 = P1PMpa4 + 10
        
    d4.after(400,Puntuacion_1PMpa4)
P1PMpa4=0
#######################################


#######################################
#Funcion para la puntuacion del player 2 del Mpa4

def Puntuacion_2PMpa4():
    """
    """
    global v5, P2PMpa4
    Puntuacion2Mpa4 = tkinter.Label(v5)
    Puntuacion2Mpa4.config(text=""+str(P2PMpa4),width=5,fg="white",bg="black",font="ARIALBLACK")
    Puntuacion2Mpa4.place(x=1240, y=100)
    if(P2PMpa4 >= 0):
        P2PMpa4 = P2PMpa4 + 10
        
    d4.after(400,Puntuacion_2PMpa4)
P2PMpa4=0
#######################################


#######################################
#Funcion para la velocidad del player 1 del Mpa4

def Velocidad_1PMpa4():
    """
    """
    global v5, V1PMpa4
    VelocidadMpa4 = tkinter.Label(v5)
    VelocidadMpa4.config(text=""+str(V1PMpa4),width=5,fg="white",bg="black",font="ARIALBLACK")
    VelocidadMpa4.place(x=575, y=300)
    if(V1PMpa4 >= 0):
        V1PMpa4 = V1PMpa4 + 1
        
    d4.after(100,Velocidad_1PMpa4)
V1PMpa4 = 0


#######################################
#Funcion para la velocidad del player 2 del Mpa4

def Velocidad_2PMpa4():
    """
    """
    global v5, V2PMpa4
    Velocidad2Mpa4 = tkinter.Label(v5)
    Velocidad2Mpa4.config(text=""+str(V2PMpa4),width=5,fg="white",bg="black",font="ARIALBLACK")
    Velocidad2Mpa4.place(x=1260, y=300)
    if(V2PMpa4 >= 0):
        V2PMpa4 = V2PMpa4 + 1
        
    d4.after(100,Velocidad_2PMpa4)
V2PMpa4 = 0


#######################################
#Funcion para el combustible del player 1 del Mpa4

def fuelMpa4():
    """
    """
    global v5, CF1Mpa4
    FuelMpa4 = tkinter.Label(v5)
    FuelMpa4.config(text=""+str(CF1Mpa4),width=5,fg="white",bg="black",font="ARIALBLACK")
    FuelMpa4.place(x=570, y=560)
    if(CF1Mpa4 > 0):
        CF1Mpa4 = CF1Mpa4-1
        
    d4.after(250,fuelMpa4)
CF1Mpa4=100


#######################################
#Funcion para el combustible del player 2 del Mpa4

def fuel2Mpa4():
    """
    """
    global v5, CF2Mpa4
    Fuel2Mpa4 = tkinter.Label(v5)
    Fuel2Mpa4.config(text=""+str(CF2Mpa4),width=5,fg="white",bg="black",font="ARIALBLACK")
    Fuel2Mpa4.place(x=1256, y=560)
    if(CF2Mpa4 > 0):
        CF2Mpa4 = CF2Mpa4 - 1
        
    d4.after(250,fuel2Mpa4)
CF2Mpa4=100



###########################################""""""""""""##############################################################################


#######################################
#Funcion para la puntuacion del player 1 del Mpa5

def Puntuacion_1PMpa5():
    """
    """
    global v6, P1PMpa5
    PuntuacionMpa5 = tkinter.Label(v6)
    PuntuacionMpa5.config(text=""+str(P1PMpa5),width=5,fg="white",bg="black",font="ARIALBLACK")
    PuntuacionMpa5.place(x=550, y=100)
    if(P1PMpa5 >= 0):
        P1PMpa5 = P1PMpa5 + 10
        
    d5.after(200,Puntuacion_1PMpa5)
P1PMpa5=0
#######################################


#######################################
#Funcion para la puntuacion del player 2 del Mpa5

def Puntuacion_2PMpa5():
    """
    """
    global v6, P2PMpa5
    Puntuacion2Mpa5 = tkinter.Label(v6)
    Puntuacion2Mpa5.config(text=""+str(P2PMpa5),width=5,fg="white",bg="black",font="ARIALBLACK")
    Puntuacion2Mpa5.place(x=1240, y=100)
    if(P2PMpa5 >= 0):
        P2PMpa5= P2PMpa5 + 10
        
    d5.after(200,Puntuacion_2PMpa5)
P2PMpa5=0
#######################################


#######################################
#Funcion para la velocidad del player 1 del Mpa5

def Velocidad_1PMpa5():
    """
    """
    global v6, V1PMpa5
    VelocidadMpa5 = tkinter.Label(v6)
    VelocidadMpa5.config(text=""+str(V1PMpa5),width=5,fg="white",bg="black",font="ARIALBLACK")
    VelocidadMpa5.place(x=575, y=300)
    if(V1PMpa5 >= 0):
        V1PMpa5 = V1PMpa5 + 1
        
    d5.after(40,Velocidad_1PMpa5)
V1PMpa5 = 0


#######################################
#Funcion para la velocidad del player 2 del Mpa5

def Velocidad_2PMpa5():
    """
    """
    global v6, V2PMpa5
    Velocidad2Mpa5 = tkinter.Label(v6)
    Velocidad2Mpa5.config(text=""+str(V2PMpa5),width=5,fg="white",bg="black",font="ARIALBLACK")
    Velocidad2Mpa5.place(x=1260, y=300)
    if(V2PMpa5 >= 0):
        V2PMpa5 = V2PMpa5 + 1
        
    d5.after(40,Velocidad_2PMpa5)
V2PMpa5 = 0


#######################################
#Funcion para el combustible del player 1 del Mpa5

def fuelMpa5():
    """
    """
    global v6, CF1Mpa5
    FuelMpa5 = tkinter.Label(v6)
    FuelMpa5.config(text=""+str(CF1Mpa5),width=5,fg="white",bg="black",font="ARIALBLACK")
    FuelMpa5.place(x=570, y=560)
    if(CF1Mpa5 > 0):
        CF1Mpa5 = CF1Mpa5-1
        
    d5.after(230,fuelMpa5)
CF1Mpa5=100


#######################################
#Funcion para el combustible del player 2 del Mpa5

def fuel2Mpa5():
    """
    """
    global v6, CF2Mpa5
    Fuel2Mpa5 = tkinter.Label(v6)
    Fuel2Mpa5.config(text=""+str(CF2Mpa5),width=5,fg="white",bg="black",font="ARIALBLACK")
    Fuel2Mpa5.place(x=1256, y=560)
    if(CF2Mpa5 > 0):
        CF2Mpa5 = CF2Mpa5 - 1
        
    d5.after(230,fuel2Mpa5)
CF2Mpa5=100


#####################################################################################################################################



#Funcion para abrir una nueva ventana Mpa1

def NuevaVentanaMpa1():
    global d1, x2, x3, entrada, entrada2, v2, xmove, ContMovMap,ContMovCochesP1,ContMovCochesP1_1,ContMovCochesP1_2,ContMovCochesP1_3,ContMovCochesP1_4, ContMovCochesP1_5, ContMovCochesP1_6,ContMovCochesP1_7, ContMovCoches, ContMovCoches1, ContMovCoches2, ContMovCoches3, ContMovCoches4, ContMovCoches5, ContMovCoches6,ContMovCoches7, xmovecochea,xmovecochea1,xmovecochea2,xmovecochea3,xmovecochea4, xmovecocheb,xmovecochec, xmovecoched, xmovecochea_,xmovecochea_1, xmovecochea_2, xmovecochea_3, xmovecochea_4,xmovecocheb_, xmovecochec_, xmovecoched_
    """
    """
    v2 = tkinter.Toplevel()
    v.iconify()
    v2.title("DODGE ROAD CARS")

    # Crea los widgets
    
    d1 = tkinter.Canvas(v2, width=1600, height=1600)
    BMpa1 = tkinter.Button(v2,text="Back",bg="black",fg="white",font="ARIALBLACK",command=backMenuMpa1)
    n1Mpa1 = tkinter.Label(v2,text=entrada.get(),bg="black",fg="red",font="ARIALBLACK")
    n2Mpa1 = tkinter.Label(v2,text=entrada2.get(),bg="black",fg="lime",font="ARIALBLACK")
    NextLv = tkinter.Button(v2,text="Next",bg="black",fg="white",font="ARIALBLACK",command=NextLevel2)

    # Carga una imagen

    

    x1 = d1.create_image(680,360,image=filename1)
    
    xmove = d1.create_image(322,348,image=filenameMove)
    xmove2 = d1.create_image(993,348,image=filenameMove2)

    x2 = d1.create_image(414,630,image=filename2)

    x3 = d1.create_image(1090,630,image=filename3)

#Coches enemigos lado izquierdo

    xmovecochea = d1.create_image(390,-110,image=filenameCochea)
    xmovecochea1 = d1.create_image(486,-310,image=filenameCochea)
    xmovecochea2 = d1.create_image(352,-510,image=filenameCochea)
    
    xmovecochea3 = d1.create_image(410,-710,image=filenameCochea)
    xmovecochea4 = d1.create_image(450,-910,image=filenameCochea)
    xmovecocheb = d1.create_image(360,-1110,image=filenameCocheb)
    xmovecochec = d1.create_image(380,-1790,image=filenameCochec)
    xmovecoched = d1.create_image(426,-2010,image=filenameCoched)
    


###########################################################################################
#Coches enemigos lado derecho

    xmovecochea_ = d1.create_image(1090,100,image=filenameCochea)
    xmovecochea_1 = d1.create_image(1020,-300,image=filenameCochea)
    xmovecochea_2 = d1.create_image(1158,-500,image=filenameCochea)

    xmovecochea_3 = d1.create_image(1070,-700,image=filenameCochea)
    xmovecochea_4 = d1.create_image(1020,-900,image=filenameCochea)
    xmovecocheb_ = d1.create_image(1090,-1100,image=filenameCocheb)
    xmovecochec_ = d1.create_image(1120,-1780,image=filenameCochec)
    xmovecoched_ = d1.create_image(1120,-2000,image=filenameCoched)
    

    

   
    
    # Empaqueta (muestra) los widgets

    d1.pack()
    BMpa1.pack()
    BMpa1.place(x=0, y =2)
    NextLv.pack()
    NextLv.place(x=2, y=40)
    n1Mpa1.pack
    n1Mpa1.place(x=540, y= 180)
    n2Mpa1.pack
    n2Mpa1.place(x=1230, y= 180)


########################################################################################################################################
#Funcion para hacer mover la carretera del jugador 1 del Mpa1

    ContMovMap = 0

    def MovMapa():
        """
        """
        global ContMovMap, d1
        if(ContMovMap < 1000000):
            d1.move(xmove,0,6)
            ContMovMap = ContMovMap + 1
            d1.after(40,MovMapa)

    MovMapa()


#Funcion para hacer mover la carretera del jugador 2 del Mpa1

    
    def Mov2Mapa():
        """
        """
        global ContMovMap, d1
        if(ContMovMap < 1000000):
            d1.move(xmove2,0,6)
            ContMovMap = ContMovMap + 1
            d1.after(40,Mov2Mapa)

    Mov2Mapa()

  
######################################################################################################################################

#Funcion para hacer mover los coches enemigos del jugador 1 del Mpa1
    ContMovCochesP1 = 0
    def MovCoche_1P():
        """
        """
        global ContMovCochesP1, d1, xmovecochea
        if(ContMovCochesP1 < 300):
                
            d1.move(xmovecochea,0,6)

            ContMovCochesP1 = ContMovCochesP1 + 1
            d1.after(40,MovCoche_1P)

        else:

            ContMovCochesP1=0
            d1.delete(xmovecochea)
            xmovecochea = d1.create_image(390,-100,image=filenameCochea)
                
            MovCoche_1P()
    MovCoche_1P()
    
########################################
    ContMovCochesP1_1 = 0
    def MovCoche_1P1():
        """
        """
        global ContMovCochesP1_1, d1, xmovecochea1
        if(ContMovCochesP1_1 < 300):
                
            d1.move(xmovecochea1,0,6)

            ContMovCochesP1_1 = ContMovCochesP1_1 + 1
            d1.after(40,MovCoche_1P1)

        else:

            ContMovCochesP1_1=0
            d1.delete(xmovecochea1)
            xmovecochea1 = d1.create_image(486,-300,image=filenameCochea)
                
            MovCoche_1P1()
    MovCoche_1P1()
    
########################################
    ContMovCochesP1_2 = 0
    def MovCoche_1P2():
        """
        """
        global ContMovCochesP1_2, d1, xmovecochea2
        if(ContMovCochesP1_2 < 360):
                
            d1.move(xmovecochea2,0,6)

            ContMovCochesP1_2 = ContMovCochesP1_2 + 1
            d1.after(40,MovCoche_1P2)

        else:

            ContMovCochesP1_2=0
            d1.delete(xmovecochea2)
            xmovecochea2 = d1.create_image(352,-500,image=filenameCochea)
                
            MovCoche_1P2()
    MovCoche_1P2()

########################################
    ContMovCochesP1_3 = 0
    def MovCoche_1P3():
        """
        """
        global ContMovCochesP1_3, d1, xmovecocheb
        if(ContMovCochesP1_3 < 360):
                
            d1.move(xmovecocheb,0,6)

            ContMovCochesP1_3 = ContMovCochesP1_3 + 1
            d1.after(40,MovCoche_1P3)

        else:

            ContMovCochesP1_3=0
            d1.delete(xmovecocheb)
            xmovecocheb = d1.create_image(360,-700,image=filenameCocheb)
                
            MovCoche_1P3()
    MovCoche_1P3()
    

    
########################################
    ContMovCochesP1_4 = 0
    def MovCoche_1P4():
        """
        """
        global ContMovCochesP1_4, d1, xmovecochea3
        if(ContMovCochesP1_4 < 400):
                
            d1.move(xmovecochea3,0,6)

            ContMovCochesP1_4 = ContMovCochesP1_4 + 1
            d1.after(40,MovCoche_1P4)

        else:

            ContMovCochesP1_4 =0
            d1.delete(xmovecochea3)
            xmovecochea3 = d1.create_image(410,-1200,image=filenameCochea)
                
            MovCoche_1P4()
    MovCoche_1P4()

########################################
    ContMovCochesP1_5 = 0
    def MovCoche_1P5():
        """
        """
        global ContMovCochesP1_5, d1, xmovecochec
        if(ContMovCochesP1_5 < 520):
                
            d1.move(xmovecochec,0,6)

            ContMovCochesP1_5 = ContMovCochesP1_5 + 1
            d1.after(40,MovCoche_1P5)

        else:

            ContMovCochesP1_5 =0
            d1.delete(xmovecochec)
            xmovecochec = d1.create_image(380,-1200,image=filenameCochec)
                
            MovCoche_1P5()
    MovCoche_1P5()
    
########################################
    ContMovCochesP1_6 = 0
    def MovCoche_1P6():
        """
        """
        global ContMovCochesP1_6, d1, xmovecochea4
        if(ContMovCochesP1_6 < 400):
                
            d1.move(xmovecochea4,0,6)

            ContMovCochesP1_6 = ContMovCochesP1_6 + 1
            d1.after(40,MovCoche_1P6)

        else:

            ContMovCochesP1_6 =0
            d1.delete(xmovecochea4)
            xmovecochea4 = d1.create_image(450,-1300,image=filenameCochea)
                
            MovCoche_1P6()
            
    MovCoche_1P6()
    
########################################
    ContMovCochesP1_7 = 0
    def MovCoche_1P7():
        """
        """
        global ContMovCochesP1_7, d1, xmovecoched
        if(ContMovCochesP1_7 < 800):
                
            d1.move(xmovecoched,0,6)

            ContMovCochesP1_7 = ContMovCochesP1_7 + 1
            d1.after(40,MovCoche_1P7)


        else:

            ContMovCochesP1_7 =0
            d1.delete(xmovecoched)
            xmovecoched = d1.create_image(426,-2000,image=filenameCoched)
                
            MovCoche_1P7()
    MovCoche_1P7()
    


######################################################################################################################################

#Funcion para hacer mover los coches enemigos del jugador 2 del Mpa1
    ContMovCoches = 0
    def MovCoche_2P():
        """
        """
        global ContMovCoches, d1, xmovecochea_
        if(ContMovCoches < 300):
                
            d1.move(xmovecochea_,0,6)

            ContMovCoches = ContMovCoches + 1
            d1.after(40,MovCoche_2P)

        else:

            ContMovCoches=0
            d1.delete(xmovecochea_)
            xmovecochea_ = d1.create_image(1090,-100,image=filenameCochea)
                
            MovCoche_2P()
    MovCoche_2P()
    
######################################     
    ContMovCoches1 = 0

    def MovCoche_2P1():
        """
        """
        global ContMovCoches1, d1, xmovecochea_1
        if(ContMovCoches1 < 300):
                
            d1.move(xmovecochea_1,0,6)

            ContMovCoches1 = ContMovCoches1 + 1
            d1.after(40,MovCoche_2P1)

        else:

            ContMovCoches1=0
            d1.delete(xmovecochea_1)
            xmovecochea_1 = d1.create_image(1110,-300,image=filenameCochea)
                
            MovCoche_2P1()
            
    MovCoche_2P1()
    
######################################     
    ContMovCoches2 = 0

    def MovCoche_2P2():
        """
        """
        global ContMovCoches2, d1, xmovecochea_2
        if(ContMovCoches2 < 360):
                
            d1.move(xmovecochea_2,0,6)

            ContMovCoches2 = ContMovCoches2 + 1
            d1.after(40,MovCoche_2P2)

        else:

            ContMovCoches2=0
            d1.delete(xmovecochea_2)
            xmovecochea_2 = d1.create_image(1030,-500,image=filenameCochea)
                
            MovCoche_2P2()
            
    MovCoche_2P2()



######################################     
    ContMovCoches3 = 0

    def MovCoche_2P3():
        """
        """
        global ContMovCoches3, d1, xmovecocheb_
        if(ContMovCoches3 < 360):
            
            d1.move(xmovecocheb_,0,6)

            ContMovCoches3 = ContMovCoches3 + 1
            d1.after(40,MovCoche_2P3)

        else:

            ContMovCoches3=0
            d1.delete(xmovecocheb_)
            xmovecocheb_ = d1.create_image(1150,-700,image=filenameCocheb)

            MovCoche_2P3()
            
    MovCoche_2P3()



######################################     
    ContMovCoches4 = 0

    def MovCoche_2P4():
        """
        """
        global ContMovCoches4, d1, xmovecochea_3
        if(ContMovCoches4 < 300):
            
            d1.move(xmovecochea_3,0,6)

            ContMovCoches4 = ContMovCoches4 + 1
            d1.after(40,MovCoche_2P4)

        else:

            ContMovCoches4=0
            d1.delete(xmovecochea_3)
            xmovecochea_4 = d1.create_image(1115,-900,image=filenameCochea)
            
            MovCoche_2P4()
            
    MovCoche_2P4()



######################################     
    ContMovCoches5 = 0

    def MovCoche_2P5():
        """
        """
        global ContMovCoches5, d1, xmovecochec_
        if(ContMovCoches5 < 520):
            
            d1.move(xmovecochec_,0,6)

            ContMovCoches5 = ContMovCoches5 + 1
            d1.after(40,MovCoche_2P5)

        else:

            ContMovCoches5=0
            
            d1.delete(xmovecochec_)
            xmovecochec_ = d1.create_image(1020,-1200,image=filenameCochec)

            MovCoche_2P5()

    MovCoche_2P5()


######################################     
    ContMovCoches6 = 0

    def MovCoche_2P6():
        """
        """
        global ContMovCoches6, d1, xmovecochea_4
        if(ContMovCoches6 < 400):
            
            d1.move(xmovecochea_4,0,6)

            ContMovCoches6 = ContMovCoches6 + 1
            d1.after(40,MovCoche_2P6)

        else:

            ContMovCoches6=0
            d1.delete(xmovecochea_4)
            xmovecochea_4 = d1.create_image(1040,-1300,image=filenameCochea)

            MovCoche_2P6()
            
    MovCoche_2P6()


######################################     
    ContMovCoches7 = 0

    def MovCoche_2P7():
        """
        """
        global ContMovCoches7, d1, xmovecoched_
        if(ContMovCoches7 < 800):
            
            d1.move(xmovecoched_,0,6)

            ContMovCoches7 = ContMovCoches7 + 1
            d1.after(40,MovCoche_2P7)

        else:

            ContMovCoches7=0
            d1.delete(xmovecoched_)
            xmovecoched_ = d1.create_image(1114,-2000,image=filenameCoched)

            MovCoche_2P7()
            
    MovCoche_2P7()

    
    
    
    

#########################################
    d1.bind("<KeyPress>",key)
    d1.bind("<KeyRelease>",key2)
    
   

    d1.focus_set()
    fuel()
    fuel2()
    Puntuacion_1P()
    Puntuacion_2P()
    Velocidad_1P()
    Velocidad_2P()
    
######################################################################################################################################


#Funcion para volver al menu Mpa2   

def backMenuMpa2():
    """
    """
    v3.destroy()
    v.deiconify()




#Funcion para avanzar al siguiente nivel 3

def NextLevel3():
    """
    """
    v3.destroy()
    NuevaVentanaMpa3()



#Funcion para abrir una nueva ventana Mpa2
    
    
def NuevaVentanaMpa2():
    global d2, x5, x6, v3, xmovempa2, Cont2MovMap, ContMovCochesP1Mpa2,ContMovCochesP1_1Mpa2,ContMovCochesP1_2Mpa2,ContMovCochesP1_3Mpa2,ContMovCochesP1_4Mpa2, ContMovCochesP1_5Mpa2, ContMovCochesP1_6Mpa2,ContMovCochesP1_7Mpa2, xmovecocheaMpa2,xmovecochea1Mpa2,xmovecochea2Mpa2,xmovecochea3Mpa2,xmovecochea4Mpa2, xmovecochebMpa2,xmovecochecMpa2, xmovecochedMpa2, ContMovCochesMpa2, ContMovCoches1Mpa2, ContMovCoches2Mpa2, ContMovCoches3Mpa2, ContMovCoches4Mpa2, ContMovCoches5Mpa2, ContMovCoches6Mpa2, ContMovCoches7Mpa2, xmovecochea_Mpa2, xmovecochea_1Mpa2, xmovecochea_2Mpa2, xmovecocheb_Mpa2, xmovecochea_3Mpa2, xmovecochec_Mpa2, xmovecochea_4Mpa2,  xmovecoched_Mpa2  
    """
    """
    v3 = tkinter.Toplevel()
    v.iconify()
    v3.title("DODGE ROAD CARS")

    # Crea los widgets
    
    d2 = tkinter.Canvas(v3, width=1600, height=1600)
    BMpa2 = tkinter.Button(v3,text="Back",bg="black",fg="white",font="ARIALBLACK",command=backMenuMpa2)
    n1Mpa2 = tkinter.Label(v3,text=entrada.get(),bg="black",fg="red",font="ARIALBLACK")
    n2Mpa2 = tkinter.Label(v3,text=entrada2.get(),bg="black",fg="lime",font="ARIALBLACK")
    Next2Lv = tkinter.Button(v3,text="Next",bg="black",fg="white",font="ARIALBLACK",command=NextLevel3)

    # Carga una imagen

    x4 = d2.create_image(680,352,image=filename4)
    
    xmovempa2 = d2.create_image(323,348,image=filenameMoveMpa2)
    xmove2mpa2 = d2.create_image(992,348,image=filenameMove2Mpa2)

    x5 = d2.create_image(324,620,image=filename5)

    x6 = d2.create_image(1002,620,image=filename6)




#Coches enemigos lado izquierdo

    xmovecocheaMpa2 = d2.create_image(290,-110,image=filenameCochea)
    xmovecochea1Mpa2 = d2.create_image(386,-310,image=filenameCochea)
    xmovecochea2Mpa2 = d2.create_image(252,-510,image=filenameCochea)
    
    xmovecochea3Mpa2 = d2.create_image(310,-710,image=filenameCochea)
    xmovecochea4Mpa2 = d2.create_image(350,-910,image=filenameCochea)
    xmovecochebMpa2 = d2.create_image(260,-1110,image=filenameCocheb)
    xmovecochecMpa2 = d2.create_image(280,-1790,image=filenameCochec)
    xmovecochedMpa2 = d2.create_image(326,-2010,image=filenameCoched)
    


###########################################################################################
#Coches enemigos lado derecho

    xmovecochea_Mpa2 = d2.create_image(990,-100,image=filenameCochea)
    xmovecochea_1Mpa2 = d2.create_image(920,-300,image=filenameCochea)
    xmovecochea_2Mpa2 = d2.create_image(1058,-500,image=filenameCochea)

    xmovecochea_3Mpa2 = d2.create_image(970,-700,image=filenameCochea)
    xmovecochea_4Mpa2 = d2.create_image(920,-900,image=filenameCochea)
    xmovecocheb_Mpa2 = d2.create_image(990,-1100,image=filenameCocheb)
    xmovecochec_Mpa2 = d2.create_image(1020,-1780,image=filenameCochec)
    xmovecoched_Mpa2 = d2.create_image(1000,-2000,image=filenameCoched)
    


    
    #Empaqueta (muestra) los widgets

    d2.pack()
    BMpa2.pack()
    BMpa2.place(x=0, y=2)
    Next2Lv.pack()
    Next2Lv.place(x=0, y=40)
    n1Mpa2.pack
    n1Mpa2.place(x=554, y= 140)
    n2Mpa2.pack
    n2Mpa2.place(x=1240, y= 140)


#Fumcion para hacer mover la carretera del jugador 1 del Mpa2

    Cont2MovMap = 0
    def MovMapa2():
        """
        """
        global Cont2MovMap, d2
        if(Cont2MovMap < 1000000):
            d2.move(xmovempa2,0,12)
            Cont2MovMap = Cont2MovMap + 1
            d2.after(40,MovMapa2)

    MovMapa2()


#Fumcion para hacer mover la carretera del jugador 2 del Mpa2

    
    def Mov2Mapa2():
        """
        """
        global Cont2MovMap, d2
        if(Cont2MovMap < 1000000):
            d2.move(xmove2mpa2,0,12)
            Cont2MovMap = Cont2MovMap + 1
            d2.after(40,Mov2Mapa2)

    Mov2Mapa2() 



######################################################################################################################################

#Funcion para hacer mover los coches enemigos del jugador 1 del Mpa2
    ContMovCochesP1Mpa2 = 0
    def MovCoche_1PMpa2():
        """
        """
        global ContMovCochesP1Mpa2, d2, xmovecocheaMpa2
        if(ContMovCochesP1Mpa2 < 300):
                
            d2.move(xmovecocheaMpa2,0,10)

            ContMovCochesP1Mpa2 = ContMovCochesP1Mpa2 + 1
            d2.after(40,MovCoche_1PMpa2)

        else:

            ContMovCochesP1Mpa2=0
            d2.delete(xmovecocheaMpa2)
            xmovecocheaMpa2 = d2.create_image(290,-100,image=filenameCochea)
                
            MovCoche_1PMpa2()
    MovCoche_1PMpa2()
    
########################################
    ContMovCochesP1_1Mpa2 = 0
    def MovCoche_1P1Mpa2():
        """
        """
        global ContMovCochesP1_1Mpa2, d2, xmovecochea1Mpa2
        if(ContMovCochesP1_1Mpa2 < 300):
                
            d2.move(xmovecochea1Mpa2,0,10)

            ContMovCochesP1_1Mpa2 = ContMovCochesP1_1Mpa2 + 1
            d2.after(40,MovCoche_1P1Mpa2)

        else:

            ContMovCochesP1_1Mpa2=0
            d2.delete(xmovecochea1Mpa2)
            xmovecochea1Mpa2 = d2.create_image(390,-300,image=filenameCochea)
                
            MovCoche_1P1Mpa2()
    MovCoche_1P1Mpa2()
    
########################################
    ContMovCochesP1_2Mpa2 = 0
    def MovCoche_1P2Mpa2():
        """
        """
        global ContMovCochesP1_2Mpa2, d2, xmovecochea2Mpa2
        if(ContMovCochesP1_2Mpa2 < 360):
                
            d2.move(xmovecochea2Mpa2,0,10)

            ContMovCochesP1_2Mpa2 = ContMovCochesP1_2Mpa2 + 1
            d2.after(40,MovCoche_1P2Mpa2)

        else:

            ContMovCochesP1_2Mpa2=0
            d2.delete(xmovecochea2Mpa2)
            xmovecochea2Mpa2 = d2.create_image(260,-500,image=filenameCochea)
                
            MovCoche_1P2Mpa2()
    MovCoche_1P2Mpa2()

########################################
    ContMovCochesP1_3Mpa2 = 0
    def MovCoche_1P3Mpa2():
        """
        """
        global ContMovCochesP1_3Mpa2, d2, xmovecochebMpa2
        if(ContMovCochesP1_3Mpa2 < 360):
                
            d2.move(xmovecochebMpa2,0,10)

            ContMovCochesP1_3Mpa2 = ContMovCochesP1_3Mpa2 + 1
            d2.after(40,MovCoche_1P3Mpa2)

        else:

            ContMovCochesP1_3Mpa2 = 0
            d2.delete(xmovecochebMpa2)
            xmovecochebMpa2 = d2.create_image(360,-700,image=filenameCocheb)
                
            MovCoche_1P3Mpa2()
    MovCoche_1P3Mpa2()
    

    
########################################
    ContMovCochesP1_4Mpa2 = 0
    def MovCoche_1P4Mpa2():
        """
        """
        global ContMovCochesP1_4Mpa2, d2, xmovecochea3Mpa2
        if(ContMovCochesP1_4Mpa2 < 400):
                
            d2.move(xmovecochea3Mpa2,0,10)

            ContMovCochesP1_4Mpa2 = ContMovCochesP1_4Mpa2 + 1
            d2.after(40,MovCoche_1P4Mpa2)

        else:

            ContMovCochesP1_4Mpa2 =0
            d2.delete(xmovecochea3Mpa2)
            xmovecochea3Mpa2 = d2.create_image(280,-1200,image=filenameCochea)
                
            MovCoche_1P4Mpa2()
    MovCoche_1P4Mpa2()

########################################
    ContMovCochesP1_5Mpa2 = 0
    def MovCoche_1P5Mpa2():
        """
        """
        global ContMovCochesP1_5Mpa2, d2, xmovecochecMpa2
        if(ContMovCochesP1_5Mpa2 < 520):
                
            d2.move(xmovecochecMpa2,0,10)

            ContMovCochesP1_5Mpa2 = ContMovCochesP1_5Mpa2 + 1
            d2.after(40,MovCoche_1P5Mpa2)

        else:

            ContMovCochesP1_5Mpa2 =0
            d2.delete(xmovecochecMpa2)
            xmovecochecMpa2 = d2.create_image(326,-1200,image=filenameCochec)
                
            MovCoche_1P5Mpa2()
    MovCoche_1P5Mpa2()
    
########################################
    ContMovCochesP1_6Mpa2 = 0
    def MovCoche_1P6Mpa2():
        """
        """
        global ContMovCochesP1_6Mpa2, d2, xmovecochea4Mpa2
        if(ContMovCochesP1_6Mpa2 < 440):
                
            d2.move(xmovecochea4Mpa2,0,10)

            ContMovCochesP1_6Mpa2 = ContMovCochesP1_6Mpa2 + 1
            d2.after(40,MovCoche_1P6Mpa2)

        else:

            ContMovCochesP1_6Mpa2 =0
            d2.delete(xmovecocheaMpa2)
            xmovecochea4Mpa2 = d2.create_image(326,-1300,image=filenameCochea)
                
            MovCoche_1P6Mpa2()
            
    MovCoche_1P6Mpa2()
    
########################################
    ContMovCochesP1_7Mpa2 = 0
    def MovCoche_1P7Mpa2():
        """
        """
        global ContMovCochesP1_7Mpa2, d2, xmovecochedMpa2
        if(ContMovCochesP1_7Mpa2 < 800):
                
            d2.move(xmovecochedMpa2,0,10)

            ContMovCochesP1_7Mpa2 = ContMovCochesP1_7Mpa2 + 1
            d2.after(40,MovCoche_1P7Mpa2)


        else:

            ContMovCochesP1_7Mpa2 =0
            d2.delete(xmovecochedMpa2)
            xmovecochedMpa2 = d2.create_image(280,-2000,image=filenameCoched)
                
            MovCoche_1P7Mpa2()
    MovCoche_1P7Mpa2()
    


######################################################################################################################################

 

######################################################################################################################################

#Funcion para hacer mover los coches enemigos del jugador 2 del Mpa1
    ContMovCochesMpa2 = 0
    def MovCoche_2PMpa2():
        """
        """
        global ContMovCochesMpa2, d2, xmovecochea_Mpa2
        if(ContMovCochesMpa2 < 300):
                
            d2.move(xmovecochea_Mpa2,0,10)

            ContMovCochesMpa2 = ContMovCochesMpa2 + 1
            d2.after(40,MovCoche_2PMpa2)

        else:

            ContMovCochesMpa2=0
            d2.delete(xmovecochea_Mpa2)
            xmovecochea_Mpa2 = d2.create_image(1090,-100,image=filenameCochea)
                
            MovCoche_2PMpa2()
    MovCoche_2PMpa2()
    
######################################     
    ContMovCoches1Mpa2 = 0

    def MovCoche_2P1Mpa2():
        """
        """
        global ContMovCoches1Mpa2, d2, xmovecochea_1Mpa2
        if(ContMovCoches1Mpa2 < 300):
                
            d2.move(xmovecochea_1Mpa2,0,10)

            ContMovCoches1Mpa2 = ContMovCoches1Mpa2 + 1
            d2.after(40,MovCoche_2P1Mpa2)

        else:

            ContMovCoches1Mpa2=0
            d2.delete(xmovecochea_1Mpa2)
            xmovecochea_1Mpa2 = d2.create_image(1090,-300,image=filenameCochea)
                
            MovCoche_2P1Mpa2()
            
    MovCoche_2P1Mpa2()
    
######################################     
    ContMovCoches2Mpa2 = 0

    def MovCoche_2P2Mpa2():
        """
        """
        global ContMovCoches2Mpa2, d2, xmovecochea_2Mpa2
        if(ContMovCoches2Mpa2 < 360):
                
            d2.move(xmovecochea_2Mpa2,0,10)

            ContMovCoches2Mpa2 = ContMovCoches2Mpa2 + 1
            d2.after(40,MovCoche_2P2Mpa2)

        else:

            ContMovCoches2Mpa2=0
            d2.delete(xmovecochea_2Mpa2)
            xmovecochea_2Mpa2 = d2.create_image(1020,-500,image=filenameCochea)
                
            MovCoche_2P2Mpa2()
            
    MovCoche_2P2Mpa2()



######################################     
    ContMovCoches3Mpa2 = 0

    def MovCoche_2P3Mpa2():
        """
        """
        global ContMovCoches3Mpa2, d2, xmovecocheb_Mpa2
        if(ContMovCoches3Mpa2 < 360):
            
            d2.move(xmovecocheb_Mpa2,0,10)

            ContMovCoches3Mpa2 = ContMovCoches3Mpa2 + 1
            d2.after(40,MovCoche_2P3Mpa2)

        else:

            ContMovCoches3Mpa2 = 0
            d2.delete(xmovecocheb_Mpa2)
            xmovecocheb_Mpa2 = d2.create_image(1050,-700,image=filenameCocheb)

            MovCoche_2P3Mpa2()
            
    MovCoche_2P3Mpa2()



######################################     
    ContMovCoches4Mpa2 = 0

    def MovCoche_2P4Mpa2():
        """
        """
        global ContMovCoches4Mpa2, d2, xmovecochea_3Mpa2
        if(ContMovCoches4Mpa2 < 300):
            
            d2.move(xmovecochea_3Mpa2,0,10)

            ContMovCoches4Mpa2 = ContMovCoches4Mpa2 + 1
            d2.after(40,MovCoche_2P4Mpa2)

        else:

            ContMovCoches4Mpa2=0
            d2.delete(xmovecochea_3Mpa2)
            xmovecochea_4Mpa2 = d2.create_image(1115,-900,image=filenameCochea)
            
            MovCoche_2P4Mpa2()
            
    MovCoche_2P4Mpa2()



######################################     
    ContMovCoches5Mpa2 = 0

    def MovCoche_2P5Mpa2():
        """
        """
        global ContMovCoches5Mpa2, d2, xmovecochec_Mpa2
        if(ContMovCoches5Mpa2 < 520):
            
            d2.move(xmovecochec_Mpa2,0,10)

            ContMovCoches5Mpa2 = ContMovCoches5Mpa2 + 1
            d2.after(40,MovCoche_2P5Mpa2)

        else:

            ContMovCoches5Mpa2=0
            
            d2.delete(xmovecochec_Mpa2)
            xmovecochec_Mpa2 = d2.create_image(1020,-1200,image=filenameCochec)

            MovCoche_2P5Mpa2()

    MovCoche_2P5Mpa2()


######################################     
    ContMovCoches6Mpa2 = 0

    def MovCoche_2P6Mpa2():
        """
        """
        global ContMovCoches6Mpa2, d2, xmovecochea_4Mpa2
        if(ContMovCoches6Mpa2 < 440):
            
            d2.move(xmovecochea_4Mpa2,0,10)

            ContMovCoches6Mpa2 = ContMovCoches6Mpa2 + 1
            d2.after(40,MovCoche_2P6Mpa2)

        else:

            ContMovCoches6Mpa2=0
            d2.delete(xmovecochea_4Mpa2)
            xmovecochea_4Mpa2 = d2.create_image(1040,-1300,image=filenameCochea)

            MovCoche_2P6Mpa2()
            
    MovCoche_2P6Mpa2()


######################################     
    ContMovCoches7Mpa2 = 0

    def MovCoche_2P7Mpa2():
        """
        """
        global ContMovCoches7Mpa2, d2, xmovecoched_Mpa2
        if(ContMovCoches7Mpa2 < 800):
            
            d2.move(xmovecoched_Mpa2,0,10)

            ContMovCoches7Mpa2 = ContMovCoches7Mpa2 + 1
            d2.after(40,MovCoche_2P7Mpa2)

        else:

            ContMovCoches7Mpa2=0
            d2.delete(xmovecoched_Mpa2)
            xmovecoched_Mpa2 = d2.create_image(1114,-2000,image=filenameCoched)

            MovCoche_2P7Mpa2()
            
    MovCoche_2P7Mpa2()

    


    
#################################################################################
    d2.bind("<KeyPress>",key3)
    d2.bind("<KeyRelease>",key4)

    d2.focus_set()
    Puntuacion_1PMpa2()
    Puntuacion_2PMpa2()
    Velocidad_1PMpa2()
    Velocidad_2PMpa2()
    fuelMpa2()
    fuel2Mpa2()
#################################################################################



#Funcion para avanzar al siguiente nivel 3

def NextLevel4():
    """
    """
    v4.destroy()
    NuevaVentanaMpa4()


#Funcion para volver al menu Mpa3 

def backMenuMpa3():
    """
    """
    v4.destroy()
    v.deiconify()


#Funcion para abrir una nueva ventana Mpa3
    
def NuevaVentanaMpa3():
    global d3, x8, x9, v4, Cont3MovMap, ContMovCochesP1Mpa3, ContMovCochesP1_1Mpa3, ContMovCochesP1_2Mpa3, ContMovCochesP1_3Mpa3, xmovecocheaMpa3, xmovecochebMpa3, xmovecochecMpa3, xmovecochedMpa3, ContMovCochesP2Mpa3,  ContMovCochesP2_1Mpa3,  ContMovCochesP2_2Mpa3,  ContMovCochesP2_3Mpa3, xmovecochea_Mpa3, xmovecocheb_Mpa3, xmovecochec_Mpa3, xmovecoched_Mpa3
    """
    """
    v4 = tkinter.Toplevel()
    v.iconify()
    v4.title("DODGE ROAD CARS")

    # Crea los widgets
    
    d3 = tkinter.Canvas(v4, width=1600, height=1600)
    BMpa3 = tkinter.Button(v4,text="Back",bg="black",fg="white",font="ARIALBLACK",command=backMenuMpa3)
    n1Mpa3 = tkinter.Label(v4,text=entrada.get(),bg="black",fg="red",font="ARIALBLACK")
    n2Mpa3 = tkinter.Label(v4,text=entrada2.get(),bg="black",fg="lime",font="ARIALBLACK")
    Next3Lv = tkinter.Button(v4,text="Next",bg="black",fg="white",font="ARIALBLACK",command=NextLevel4)

    # Carga una imagen

    x7 = d3.create_image(680,352,image=filename7)

    xmovempa3 = d3.create_image(325,348,image=filenameMoveMpa3)
    xmove2mpa3 = d3.create_image(994,348,image=filenameMove2Mpa3)

    x8 = d3.create_image(262,620,image=filename8)

    x9 = d3.create_image(930,620,image=filename9)




#Coches enemigos lado izquierdo

    xmovecocheaMpa3 = d3.create_image(296,-110,image=filenameCochea)
    xmovecochebMpa3 = d3.create_image(236,-310,image=filenameCocheb)
    xmovecochecMpa3 = d3.create_image(266,-510,image=filenameCochec)
    xmovecochedMpa3 = d3.create_image(236,-1210,image=filenameCoched)
    


###########################################################################################
#Coches enemigos lado derecho

    xmovecochea_Mpa3 = d3.create_image(966,-100,image=filenameCochea)
    xmovecocheb_Mpa3 = d3.create_image(906,-300,image=filenameCocheb)
    xmovecochec_Mpa3 = d3.create_image(936,-500,image=filenameCochec)
    xmovecoched_Mpa3 = d3.create_image(906,-1200,image=filenameCoched)
    



    
    # Empaqueta (muestra) los widgets

    d3.pack()
    BMpa3.place()
    BMpa3.place(x=0, y=2)
    Next3Lv.pack()
    Next3Lv.place(x=0, y=40)
    n1Mpa3.pack
    n1Mpa3.place(x=554, y= 150)
    n2Mpa3.pack
    n2Mpa3.place(x=1240, y= 150)


#Fumcion para hacer mover la carretera del jugador 1 del Mpa3

    Cont3MovMap = 0
    def MovMapa3():
        """
        """
        global Cont3MovMap, d3
        if(Cont3MovMap < 1000000):
            d3.move(xmovempa3,0,14)
            Cont3MovMap = Cont3MovMap + 1
            d3.after(40,MovMapa3)

    MovMapa3()


#Fumcion para hacer mover la carretera del jugador 2 del Mpa3

    
    def Mov2Mapa3():
        """
        """
        global Cont3MovMap, d3
        if(Cont3MovMap < 1000000):
            d3.move(xmove2mpa3,0,14)
            Cont3MovMap = Cont3MovMap + 1
            d3.after(40,Mov2Mapa3)

    Mov2Mapa3() 


######################################################################################################################################

#Funcion para hacer mover los coches enemigos del jugador 1 del Mpa3
    ContMovCochesP1Mpa3 = 0
    def MovCoche_1PMpa3():
        """
        """
        global ContMovCochesP1Mpa3, d3, xmovecocheaMpa3
        if(ContMovCochesP1Mpa3 < 80):
                
            d3.move(xmovecocheaMpa3,0,15)

            ContMovCochesP1Mpa3 = ContMovCochesP1Mpa3 + 1
            d3.after(40,MovCoche_1PMpa3)

        else:

            ContMovCochesP1Mpa3=0
            d3.delete(xmovecocheaMpa3)
            xmovecocheaMpa3 = d3.create_image(296,-100,image=filenameCochea)
                
            MovCoche_1PMpa3()
    MovCoche_1PMpa3()


########################################
    ContMovCochesP1_1Mpa3 = 0
    def MovCoche_1P2Mpa3():
        """
        """
        global ContMovCochesP1_1Mpa3, d3, xmovecochebMpa3
        if(ContMovCochesP1_1Mpa3 < 100):
                
            d3.move(xmovecochebMpa3,0,15)

            ContMovCochesP1_1Mpa3 = ContMovCochesP1_1Mpa3 + 1
            d3.after(40,MovCoche_1P2Mpa3)

        else:

            ContMovCochesP1_1Mpa3 = 0
            d3.delete(xmovecochebMpa3)
            xmovecochebMpa3 = d3.create_image(236,-200,image=filenameCocheb)
                
            MovCoche_1P2Mpa3()
    MovCoche_1P2Mpa3()
    

########################################
    ContMovCochesP1_2Mpa3 = 0
    def MovCoche_1P3Mpa3():
        """
        """
        global ContMovCochesP1_2Mpa3, d3, xmovecochecMpa3
        if(ContMovCochesP1_2Mpa3 < 120):
                
            d3.move(xmovecochecMpa3,0,15)

            ContMovCochesP1_2Mpa3 = ContMovCochesP1_2Mpa3 + 1
            d3.after(40,MovCoche_1P3Mpa3)

        else:

            ContMovCochesP1_2Mpa3 =0
            d3.delete(xmovecochecMpa3)
            xmovecochecMpa3 = d3.create_image(266,-300,image=filenameCochec)
                
            MovCoche_1P3Mpa3()
    MovCoche_1P3Mpa3()

    
########################################
    ContMovCochesP1_3Mpa3 = 0
    def MovCoche_1P4Mpa3():
        """
        """
        global ContMovCochesP1_3Mpa3, d3, xmovecochedMpa3
        if(ContMovCochesP1_3Mpa3 < 280):
                
            d3.move(xmovecochedMpa3,0,15)

            ContMovCochesP1_3Mpa3 = ContMovCochesP1_3Mpa3 + 1
            d3.after(40,MovCoche_1P4Mpa3)


        else:

            ContMovCochesP1_3Mpa3 =0
            d3.delete(xmovecochedMpa3)
            xmovecochedMpa3 = d3.create_image(236,-400,image=filenameCoched)
                
            MovCoche_1P4Mpa3()
    MovCoche_1P4Mpa3()



########################################################################################################################################

    
######################################################################################################################################

#Funcion para hacer mover los coches enemigos del jugador 2 del Mpa3
    ContMovCochesP2Mpa3 = 0
    def MovCoche_2PMpa3():
        """
        """
        global ContMovCochesP2Mpa3, d3, xmovecochea_Mpa3
        if(ContMovCochesP2Mpa3 < 100):
                
            d3.move(xmovecochea_Mpa3,0,15)

            ContMovCochesP2Mpa3 = ContMovCochesP2Mpa3 + 1
            d3.after(40,MovCoche_2PMpa3)

        else:

            ContMovCochesP2Mpa3=0
            d3.delete(xmovecochea_Mpa3)
            xmovecochea_Mpa3 = d3.create_image(906,-120,image=filenameCochea)
                
            MovCoche_2PMpa3()
    MovCoche_2PMpa3()


########################################
    ContMovCochesP2_1Mpa3 = 0
    def MovCoche_2P2Mpa3():
        """
        """
        global ContMovCochesP2_1Mpa3, d3, xmovecocheb_Mpa3
        if(ContMovCochesP2_1Mpa3 < 120):
                
            d3.move(xmovecocheb_Mpa3,0,15)

            ContMovCochesP2_1Mpa3 = ContMovCochesP2_1Mpa3 + 1
            d3.after(40,MovCoche_2P2Mpa3)

        else:

            ContMovCochesP2_1Mpa3 = 0
            d3.delete(xmovecocheb_Mpa3)
            xmovecocheb_Mpa3 = d3.create_image(936,-220,image=filenameCocheb)
                
            MovCoche_2P2Mpa3()
    MovCoche_2P2Mpa3()
    

########################################
    ContMovCochesP2_2Mpa3 = 0
    def MovCoche_2P3Mpa3():
        """
        """
        global ContMovCochesP2_2Mpa3, d3, xmovecochec_Mpa3
        if(ContMovCochesP2_2Mpa3 < 140):
                
            d3.move(xmovecochec_Mpa3,0,15)

            ContMovCochesP2_2Mpa3 = ContMovCochesP2_2Mpa3 + 1
            d3.after(40,MovCoche_2P3Mpa3)

        else:

            ContMovCochesP2_2Mpa3 =0
            d3.delete(xmovecochec_Mpa3)
            xmovecochec_Mpa3 = d3.create_image(906,-320,image=filenameCochec)
                
            MovCoche_2P3Mpa3()
    MovCoche_2P3Mpa3()

    
########################################
    ContMovCochesP2_3Mpa3 = 0
    def MovCoche_2P4Mpa3():
        """
        """
        global ContMovCochesP2_3Mpa3, d3, xmovecoched_Mpa3
        if(ContMovCochesP2_3Mpa3 < 320):
                
            d3.move(xmovecoched_Mpa3,0,15)

            ContMovCochesP2_3Mpa3 = ContMovCochesP2_3Mpa3 + 1
            d3.after(40,MovCoche_2P4Mpa3)


        else:

            ContMovCochesP2_3Mpa3 =0
            d3.delete(xmovecoched_Mpa3)
            xmovecoched_Mpa3 = d3.create_image(966,-420,image=filenameCoched)
                    
            MovCoche_2P4Mpa3()
    MovCoche_2P4Mpa3()



########################################################################################################################################


###################################
    d3.bind("<KeyPress>",key5)
    d3.bind("<KeyRelease>",key6)

    d3.focus_set()
    Puntuacion_1PMpa3()
    Puntuacion_2PMpa3()
    Velocidad_1PMpa3()
    Velocidad_2PMpa3()
    fuelMpa3()
    fuel2Mpa3()
    
###################################


#Funcion para avanzar al siguiente nivel 5

def NextLevel5():
    """
    """
    v5.destroy()
    NuevaVentanaMpa5()


#Funcion para volver al menu Mpa4 

def backMenuMpa4():
    """
    """
    v5.destroy()
    v.deiconify()


#Funcion para abrir una nueva ventana Mpa4
    
def NuevaVentanaMpa4():
    global d4, x11, x12, v5, Cont4MovMap, ContMovCochesP1Mpa4, ContMovCochesP1_1Mpa4, ContMovCochesP1_2Mpa4, ContMovCochesP1_3Mpa4, ContMovCochesP1_4Mpa4, ContMovCochesP1_5Mpa4, ContMovCochesP1_6Mpa4, ContMovCochesP1_7Mpa4, xmovecocheaMpa4, xmovecochea1Mpa4, xmovecochea2Mpa4, xmovecochea3Mpa4, xmovecochea4Mpa4, xmovecochebMpa4, xmovecochecMpa4, xmovecochedMpa4, ContMovCochesP2Mpa4, ContMovCochesP2_1Mpa4, ContMovCochesP2_2Mpa4, ContMovCochesP2_3Mpa4, ContMovCochesP2_4Mpa4, ContMovCochesP2_5Mpa4, ContMovCochesP2_6Mpa4, ContMovCochesP2_7Mpa4, xmovecochea_Mpa4, xmovecochea_1Mpa4, xmovecochea_2Mpa4, xmovecochea_3Mpa4, xmovecochea_4Mpa4, xmovecocheb_Mpa4, xmovecochec_Mpa4, xmovecoched_Mpa4  
    """
    """
    v5 = tkinter.Toplevel()
    v.iconify()
    v5.title("DODGE ROAD CARS")

    # Crea los widgets
    
    d4 = tkinter.Canvas(v5, width=1600, height=1600)
    BMpa4 = tkinter.Button(v5,text="Back",bg="black",fg="white",font="ARIALBLACK",command=backMenuMpa4)
    n1Mpa4 = tkinter.Label(v5,text=entrada.get(),bg="black",fg="red",font="ARIALBLACK")
    n2Mpa4 = tkinter.Label(v5,text=entrada2.get(),bg="black",fg="lime",font="ARIALBLACK")
    Next4Lv = tkinter.Button(v5,text="Next",bg="black",fg="white",font="ARIALBLACK",command=NextLevel5)
    # Carga una imagen

    x10 = d4.create_image(680,352,image=filename10)

    xmovempa4 = d4.create_image(321,348,image=filenameMoveMpa4)
    xmove2mpa4 = d4.create_image(992,348,image=filenameMove2Mpa4)

    x11 = d4.create_image(390,620,image=filename11)

    x12 = d4.create_image(1060,620,image=filename12)




#Coches enemigos lado izquierdo

    xmovecocheaMpa4 = d4.create_image(390,-110,image=filenameCochea)
    xmovecochea1Mpa4 = d4.create_image(448,-310,image=filenameCochea)
    xmovecochea2Mpa4 = d4.create_image(340,-510,image=filenameCochea)
    
    xmovecochea3Mpa4 = d4.create_image(448,-710,image=filenameCochea)
    xmovecochea4Mpa4 = d4.create_image(340,-910,image=filenameCochea)
    xmovecochebMpa4 = d4.create_image(382,-1110,image=filenameCocheb)
    xmovecochecMpa4 = d4.create_image(440,-1790,image=filenameCochec)
    xmovecochedMpa4 = d4.create_image(390,-2010,image=filenameCoched)
    


###########################################################################################
#Coches enemigos lado derecho

    xmovecochea_Mpa4 = d4.create_image(1010,-100,image=filenameCochea)
    xmovecochea_1Mpa4 = d4.create_image(1020,-300,image=filenameCochea)
    xmovecochea_2Mpa4 = d4.create_image(1126,-500,image=filenameCochea)

    xmovecochea_3Mpa4 = d4.create_image(1070,-700,image=filenameCochea)
    xmovecochea_4Mpa4 = d4.create_image(1020,-900,image=filenameCochea)
    xmovecocheb_Mpa4 = d4.create_image(1090,-1100,image=filenameCocheb)
    xmovecochec_Mpa4 = d4.create_image(1120,-1780,image=filenameCochec)
    xmovecoched_Mpa4 = d4.create_image(1120,-2000,image=filenameCoched)
    


    
    # Empaqueta (muestra) los widgets

    d4.pack()
    BMpa4.pack()
    BMpa4.place(x=0, y=2)
    Next4Lv.pack
    Next4Lv.place(x=0, y=40)
    n1Mpa4.pack
    n1Mpa4.place(x=540, y= 180)
    n2Mpa4.pack
    n2Mpa4.place(x=1230, y= 180)


#Fumcion para hacer mover la carretera del jugador 1 del Mpa4

    Cont4MovMap = 0
    def MovMapa4():
        """
        """
        global Cont4MovMap, d4
        if(Cont4MovMap < 1000000):
            d4.move(xmovempa4,0,18)
            Cont4MovMap = Cont4MovMap + 1
            d4.after(40,MovMapa4)

    MovMapa4()


#Fumcion para hacer mover la carretera del jugador 2 del Mpa4

    
    def Mov2Mapa4():
        """
        """
        global Cont4MovMap, d4
        if(Cont4MovMap < 1000000):
            d4.move(xmove2mpa4,0,18)
            Cont4MovMap = Cont4MovMap + 1
            d4.after(40,Mov2Mapa4)

    Mov2Mapa4() 




######################################################################################################################################

#Funcion para hacer mover los coches enemigos del jugador 1 del Mpa4
    ContMovCochesP1Mpa4 = 0
    def MovCoche_1PMpa4():
        """
        """
        global ContMovCochesP1Mpa4, d4, xmovecocheaMpa4
        if(ContMovCochesP1Mpa4 < 200):
                
            d4.move(xmovecocheaMpa4,0,20)

            ContMovCochesP1Mpa4 = ContMovCochesP1Mpa4 + 1
            d4.after(40,MovCoche_1PMpa4)

        else:

            ContMovCochesP1Mpa4=0
            d4.delete(xmovecocheaMpa4)
            xmovecocheaMpa4 = d4.create_image(390,-110,image=filenameCochea)
                
            MovCoche_1PMpa4()
    MovCoche_1PMpa4()
    
########################################
    ContMovCochesP1_1Mpa4 = 0
    def MovCoche_1P1Mpa4():
        """
        """
        global ContMovCochesP1_1Mpa4, d4, xmovecochea1Mpa4
        if(ContMovCochesP1_1Mpa4 < 260):
                
            d4.move(xmovecochea1Mpa4,0,20)

            ContMovCochesP1_1Mpa4 = ContMovCochesP1_1Mpa4 + 1
            d4.after(40,MovCoche_1P1Mpa4)

        else:

            ContMovCochesP1_1Mpa4=0
            d4.delete(xmovecochea1Mpa4)
            xmovecochea1Mpa4 = d4.create_image(448,-210,image=filenameCochea)
                
            MovCoche_1P1Mpa4()
    MovCoche_1P1Mpa4()
    
########################################
    ContMovCochesP1_2Mpa4 = 0
    def MovCoche_1P2Mpa4():
        """
        """
        global ContMovCochesP1_2Mpa4, d4, xmovecochea2Mpa4
        if(ContMovCochesP1_2Mpa4 < 300):
                
            d4.move(xmovecochea2Mpa4,0,20)

            ContMovCochesP1_2Mpa4 = ContMovCochesP1_2Mpa4 + 1
            d4.after(40,MovCoche_1P2Mpa4)

        else:

            ContMovCochesP1_2Mpa4=0
            d4.delete(xmovecochea2Mpa4)
            xmovecochea2Mpa4 = d4.create_image(340,-310,image=filenameCochea)
                
            MovCoche_1P2Mpa4()
    MovCoche_1P2Mpa4()

########################################
    ContMovCochesP1_3Mpa4 = 0
    def MovCoche_1P3Mpa4():
        """
        """
        global ContMovCochesP1_3Mpa4, d4, xmovecochebMpa4
        if(ContMovCochesP1_3Mpa4 < 320):
                
            d4.move(xmovecochebMpa4,0,20)

            ContMovCochesP1_3Mpa4 = ContMovCochesP1_3Mpa4 + 1
            d4.after(40,MovCoche_1P3Mpa4)

        else:

            ContMovCochesP1_3Mpa4=0
            d4.delete(xmovecochebMpa4)
            xmovecochebMpa4 = d4.create_image(448,-410,image=filenameCocheb)
                
            MovCoche_1P3Mpa4()
    MovCoche_1P3Mpa4()
    

    
########################################
    ContMovCochesP1_4Mpa4 = 0
    def MovCoche_1P4Mpa4():
        """
        """
        global ContMovCochesP1_4Mpa4, d4, xmovecochea3Mpa4
        if(ContMovCochesP1_4Mpa4 < 340):
                
            d4.move(xmovecochea3Mpa4,0,20)

            ContMovCochesP1_4Mpa4 = ContMovCochesP1_4Mpa4 + 1
            d4.after(40,MovCoche_1P4Mpa4)

        else:

            ContMovCochesP1_4Mpa4 =0
            d4.delete(xmovecochea3Mpa4)
            xmovecochea3Mpa4 = d4.create_image(340,-510,image=filenameCochea)
                
            MovCoche_1P4Mpa4()
    MovCoche_1P4Mpa4()

########################################
    ContMovCochesP1_5Mpa4 = 0
    def MovCoche_1P5Mpa4():
        """
        """
        global ContMovCochesP1_5Mpa4, d4, xmovecochecMpa4
        if(ContMovCochesP1_5Mpa4 < 360):
                
            d4.move(xmovecochecMpa4,0,20)

            ContMovCochesP1_5Mpa4 = ContMovCochesP1_5Mpa4 + 1
            d4.after(40,MovCoche_1P5Mpa4)

        else:

            ContMovCochesP1_5Mpa4 = 0
            d4.delete(xmovecochecMpa4)
            xmovecochecMpa4 = d4.create_image(382,-710,image=filenameCochec)
                
            MovCoche_1P5Mpa4()
    MovCoche_1P5Mpa4()
    
########################################
    ContMovCochesP1_6Mpa4 = 0
    def MovCoche_1P6Mpa4():
        """
        """
        global ContMovCochesP1_6Mpa4, d4, xmovecochea4Mpa4
        if(ContMovCochesP1_6Mpa4 < 400):
                
            d4.move(xmovecochea4Mpa4,0,20)

            ContMovCochesP1_6Mpa4 = ContMovCochesP1_6Mpa4 + 1
            d4.after(40,MovCoche_1P6Mpa4)

        else:

            ContMovCochesP1_6Mpa4 =0
            d4.delete(xmovecochea4Mpa4)
            xmovecochea4Mpa4 = d4.create_image(440,-910,image=filenameCochea)
                
            MovCoche_1P6Mpa4()
            
    MovCoche_1P6Mpa4()
    
########################################
    ContMovCochesP1_7Mpa4 = 0
    def MovCoche_1P7Mpa4():
        """
        """
        global ContMovCochesP1_7Mpa4, d4, xmovecochedMpa4
        if(ContMovCochesP1_7Mpa4 < 600):
                
            d4.move(xmovecochedMpa4,0,20)

            ContMovCochesP1_7Mpa4 = ContMovCochesP1_7Mpa4 + 1
            d4.after(40,MovCoche_1P7Mpa4)


        else:

            ContMovCochesP1_7Mpa4 =0
            d4.delete(xmovecochedMpa4)
            xmovecochedMpa4 = d4.create_image(390,-1410,image=filenameCoched)
                
            MovCoche_1P7Mpa4()
    MovCoche_1P7Mpa4()
    
######################################################################################################################################


######################################################################################################################################

#Funcion para hacer mover los coches enemigos del jugador 2 del Mpa4
    ContMovCochesP2Mpa4 = 0
    def MovCoche_2PMpa4():
        """
        """
        global ContMovCochesP2Mpa4, d4, xmovecochea_Mpa4
        if(ContMovCochesP2Mpa4 < 200):
                
            d4.move(xmovecochea_Mpa4,0,20)

            ContMovCochesP2Mpa4 = ContMovCochesP2Mpa4 + 1
            d4.after(40,MovCoche_2PMpa4)

        else:

            ContMovCochesP2Mpa4=0
            d4.delete(xmovecochea_Mpa4)
            xmovecochea_Mpa4 = d4.create_image(1010,-110,image=filenameCochea)
                
            MovCoche_2PMpa4()
    MovCoche_2PMpa4()
    
########################################
    ContMovCochesP2_1Mpa4 = 0
    def MovCoche_2P1Mpa4():
        """
        """
        global ContMovCochesP2_1Mpa4, d4, xmovecochea_1Mpa4
        if(ContMovCochesP2_1Mpa4 < 260):
                
            d4.move(xmovecochea_1Mpa4,0,20)

            ContMovCochesP2_1Mpa4 = ContMovCochesP2_1Mpa4 + 1
            d4.after(40,MovCoche_2P1Mpa4)

        else:

            ContMovCochesP2_1Mpa4=0
            d4.delete(xmovecochea_1Mpa4)
            xmovecochea_1Mpa4 = d4.create_image(1020,-300,image=filenameCochea)
                
            MovCoche_2P1Mpa4()
    MovCoche_2P1Mpa4()
    
########################################
    ContMovCochesP2_2Mpa4 = 0
    def MovCoche_2P2Mpa4():
        """
        """
        global ContMovCochesP2_2Mpa4, d4, xmovecochea_2Mpa4
        if(ContMovCochesP2_2Mpa4 < 220):
                
            d4.move(xmovecochea_2Mpa4,0,20)

            ContMovCochesP2_2Mpa4 = ContMovCochesP2_2Mpa4 + 1
            d4.after(40,MovCoche_2P2Mpa4)

        else:

            ContMovCochesP2_2Mpa4=0
            d4.delete(xmovecochea_2Mpa4)
            xmovecochea_2Mpa4 = d4.create_image(1120,-500,image=filenameCochea)
                
            MovCoche_2P2Mpa4()
    MovCoche_2P2Mpa4()

########################################
    ContMovCochesP2_3Mpa4 = 0
    def MovCoche_2P3Mpa4():
        """
        """
        global ContMovCochesP2_3Mpa4, d4, xmovecocheb_Mpa4
        if(ContMovCochesP2_3Mpa4 < 320):
                
            d4.move(xmovecocheb_Mpa4,0,20)

            ContMovCochesP2_3Mpa4 = ContMovCochesP2_3Mpa4 + 1
            d4.after(40,MovCoche_2P3Mpa4)

        else:

            ContMovCochesP2_3Mpa4=0
            d4.delete(xmovecocheb_Mpa4)
            xmovecocheb_Mpa4 = d4.create_image(1060,-700,image=filenameCocheb)
                
            MovCoche_2P3Mpa4()
    MovCoche_2P3Mpa4()
    

    
########################################
    ContMovCochesP2_4Mpa4 = 0
    def MovCoche_2P4Mpa4():
        """
        """
        global ContMovCochesP2_4Mpa4, d4, xmovecochea_3Mpa4
        if(ContMovCochesP2_4Mpa4 < 320):
                
            d4.move(xmovecochea_3Mpa4,0,20)

            ContMovCochesP2_4Mpa4 = ContMovCochesP2_4Mpa4 + 1
            d4.after(40,MovCoche_2P4Mpa4)

        else:

            ContMovCochesP2_4Mpa4 =0
            d4.delete(xmovecochea_3Mpa4)
            xmovecochea_3Mpa4 = d4.create_image(1020,-900,image=filenameCochea)
                
            MovCoche_2P4Mpa4()
    MovCoche_2P4Mpa4()

########################################
    ContMovCochesP2_5Mpa4 = 0
    def MovCoche_2P5Mpa4():
        """
        """
        global ContMovCochesP2_5Mpa4, d4, xmovecochec_Mpa4
        if(ContMovCochesP2_5Mpa4 < 360):
                
            d4.move(xmovecochec_Mpa4,0,20)

            ContMovCochesP2_5Mpa4 = ContMovCochesP2_5Mpa4 + 1
            d4.after(40,MovCoche_2P5Mpa4)

        else:

            ContMovCochesP2_5Mpa4 = 0
            d4.delete(xmovecochec_Mpa4)
            xmovecochec_Mpa4 = d4.create_image(1090,-1100,image=filenameCochec)
                
            MovCoche_2P5Mpa4()
    MovCoche_2P5Mpa4()
    
########################################
    ContMovCochesP2_6Mpa4 = 0
    def MovCoche_2P6Mpa4():
        """
        """
        global ContMovCochesP2_6Mpa4, d4, xmovecochea_4Mpa4
        if(ContMovCochesP2_6Mpa4 < 400):
                
            d4.move(xmovecochea_4Mpa4,0,20)

            ContMovCochesP2_6Mpa4 = ContMovCochesP2_6Mpa4 + 1
            d4.after(40,MovCoche_2P6Mpa4)

        else:

            ContMovCochesP2_6Mpa4 =0
            d4.delete(xmovecochea_4Mpa4)
            xmovecochea_4Mpa4 = d4.create_image(1120,-1700,image=filenameCochea)
                
            MovCoche_2P6Mpa4()
            
    MovCoche_2P6Mpa4()
    
########################################
    ContMovCochesP2_7Mpa4 = 0
    def MovCoche_2P7Mpa4():
        """
        """
        global ContMovCochesP2_7Mpa4, d4, xmovecoched_Mpa4
        if(ContMovCochesP2_7Mpa4 < 600):
                
            d4.move(xmovecoched_Mpa4,0,20)

            ContMovCochesP2_7Mpa4 = ContMovCochesP2_7Mpa4 + 1
            d4.after(40,MovCoche_2P7Mpa4)


        else:

            ContMovCochesP2_7Mpa4 =0
            d4.delete(xmovecoched_Mpa4)
            xmovecoched_Mpa4 = d4.create_image(1120,-2000,image=filenameCoched)
                
            MovCoche_2P7Mpa4()
    MovCoche_2P7Mpa4()
    
######################################################################################################################################




        
###################################
    d4.bind("<KeyPress>",key7)
    d4.bind("<KeyRelease>",key8)

    d4.focus_set()
    Puntuacion_1PMpa4()
    Puntuacion_2PMpa4()
    Velocidad_1PMpa4()
    Velocidad_2PMpa4()
    fuelMpa4()
    fuel2Mpa4()

    
################################### 


#Funcion para volver al menu Mpa4 

def backMenuMpa5():
    """
    """
    v6.destroy()
    v.deiconify()

#Funcion para abrir una nueva ventana Mpa5
    
def NuevaVentanaMpa5():
    global d5, x14, x15, v6, Cont5MovMap, ContMovCochesP1Mpa5,ContMovCochesP1_1Mpa5,ContMovCochesP1_2Mpa5,ContMovCochesP1_3Mpa5,ContMovCochesP1_4Mpa5, ContMovCochesP1_5Mpa5, ContMovCochesP1_6Mpa5,ContMovCochesP1_7Mpa5, xmovecocheaMpa5,xmovecochea1Mpa5, xmovecochea2Mpa5, xmovecochea3Mpa5, xmovecochea4Mpa5, xmovecochebMpa5, xmovecochecMpa5, xmovecochedMpa5,  ContMovCochesMpa5,  ContMovCoches1Mpa5,  ContMovCoches2Mpa5,  ContMovCoches3Mpa5,  ContMovCoches4Mpa5,  ContMovCoches5Mpa5,  ContMovCoches5Mpa5,  ContMovCoches6Mpa5,  ContMovCoches7Mpa5, xmovecochea_Mpa5, xmovecochea_1Mpa5, xmovecochea_2Mpa5, xmovecochea_3Mpa5, xmovecochea_4Mpa5, xmovecocheb_Mpa5, xmovecochec_Mpa5, xmovecoched_Mpa5 
    """
    """
    v6 = tkinter.Toplevel()
    v.iconify()
    v6.title("DODGE ROAD CARS")

    # Crea los widgets
    
    d5 = tkinter.Canvas(v6, width=1600, height=1600)
    BMpa5 = tkinter.Button(v6,text="Back",bg="black",fg="white",font="ARIALBLACK",command=backMenuMpa5)
    n1Mpa5 = tkinter.Label(v6,text=entrada.get(),bg="black",fg="red",font="ARIALBLACK")
    n2Mpa5 = tkinter.Label(v6,text=entrada2.get(),bg="black",fg="lime",font="ARIALBLACK")

    # Carga una imagen

    x13 = d5.create_image(680,352,image=filename13)

    xmovempa5 = d5.create_image(322,348,image=filenameMoveMpa5)
    xmove2mpa5 = d5.create_image(993,348,image=filenameMove2Mpa5)

    x14 = d5.create_image(414,630,image=filename14)

    x15 = d5.create_image(1090,630,image=filename15)




#Coches enemigos lado izquierdo

    xmovecocheaMpa5 = d5.create_image(390,-110,image=filenameCochea1)
    xmovecochea1Mpa5 = d5.create_image(486,-310,image=filenameCochea1)
    xmovecochea2Mpa5 = d5.create_image(352,-510,image=filenameCochea1)
    
    xmovecochea3Mpa5 = d5.create_image(410,-710,image=filenameCochea1)
    xmovecochea4Mpa5 = d5.create_image(450,-910,image=filenameCochea1)
    xmovecochebMpa5 = d5.create_image(360,-1110,image=filenameCocheb1)
    xmovecochecMpa5 = d5.create_image(380,-1790,image=filenameCochec1)
    xmovecochedMpa5 = d5.create_image(426,-2010,image=filenameCoched1)
    


###########################################################################################
#Coches enemigos lado derecho

    xmovecochea_Mpa5 = d5.create_image(1090,-100,image=filenameCochea1)
    xmovecochea_1Mpa5 = d5.create_image(1020,-300,image=filenameCochea1)
    xmovecochea_2Mpa5 = d5.create_image(1158,-500,image=filenameCochea1)

    xmovecochea_3Mpa5 = d5.create_image(1070,-700,image=filenameCochea1)
    xmovecochea_4Mpa5 = d5.create_image(1020,-900,image=filenameCochea1)
    xmovecocheb_Mpa5 = d5.create_image(1090,-1100,image=filenameCocheb1)
    xmovecochec_Mpa5 = d5.create_image(1120,-1780,image=filenameCochec1)
    xmovecoched_Mpa5 = d5.create_image(1120,-2000,image=filenameCoched1)
    

    


    
    # Empaqueta (muestra) los widgets

    d5.pack()
    BMpa5.pack()
    BMpa5.place(x=0, y=2)
    n1Mpa5.pack
    n1Mpa5.place(x=540, y= 180)
    n2Mpa5.pack
    n2Mpa5.place(x=1230, y= 180)


#Fumcion para hacer mover la carretera del jugador 1 del Mpa5

    Cont5MovMap = 0
    def MovMapa5():
        """
        """
        global Cont5MovMap, d5
        if(Cont5MovMap < 1000000):
            d5.move(xmovempa5,0,20)
            Cont5MovMap = Cont5MovMap + 1
            d5.after(40,MovMapa5)

    MovMapa5()


#Fumcion para hacer mover la carretera del jugador 2 del Mpa5

    
    def Mov2Mapa5():
        """
        """
        global Cont5MovMap, d4
        if(Cont5MovMap < 1000000):
            d5.move(xmove2mpa5,0,20)
            Cont5MovMap = Cont5MovMap + 1
            d5.after(40,Mov2Mapa5)

    Mov2Mapa5() 

        

  
######################################################################################################################################

#Funcion para hacer mover los coches enemigos del jugador 1 del Mpa5
    ContMovCochesP1Mpa5 = 0
    def MovCoche_1PMpa5():
        """
        """
        global ContMovCochesP1Mpa5, d5, xmovecocheaMpa5
        if(ContMovCochesP1Mpa5 < 300):
                
            d5.move(xmovecocheaMpa5,0,30)

            ContMovCochesP1Mpa5 = ContMovCochesP1Mpa5 + 1
            d5.after(40,MovCoche_1PMpa5)

        else:

            ContMovCochesP1Mpa5=0
            d5.delete(xmovecocheaMpa5)
            xmovecocheaMpa5 = d5.create_image(390,-100,image=filenameCochea1)
                
            MovCoche_1PMpa5()
    MovCoche_1PMpa5()
    
########################################
    ContMovCochesP1_1Mpa5 = 0
    def MovCoche_1P1Mpa5():
        """
        """
        global ContMovCochesP1_1Mpa5, d5, xmovecochea1Mpa5
        if(ContMovCochesP1_1Mpa5 < 300):
                
            d5.move(xmovecochea1Mpa5,0,30)

            ContMovCochesP1_1Mpa5 = ContMovCochesP1_1Mpa5 + 1
            d5.after(40,MovCoche_1P1Mpa5)

        else:

            ContMovCochesP1_1Mpa5=0
            d5.delete(xmovecochea1Mpa5)
            xmovecochea1Mpa5 = d5.create_image(486,-300,image=filenameCochea1)
                
            MovCoche_1P1Mpa5()
    MovCoche_1P1Mpa5()
    
########################################
    ContMovCochesP1_2Mpa5 = 0
    def MovCoche_1P2Mpa5():
        """
        """
        global ContMovCochesP1_2Mpa5, d5, xmovecochea2Mpa5
        if(ContMovCochesP1_2Mpa5 < 360):
                
            d5.move(xmovecochea2Mpa5,0,30)

            ContMovCochesP1_2Mpa5 = ContMovCochesP1_2Mpa5 + 1
            d5.after(40,MovCoche_1P2Mpa5)

        else:

            ContMovCochesP1_2Mpa5 = 0
            d5.delete(xmovecochea2Mpa5)
            xmovecochea2Mpa5 = d5.create_image(352,-500,image=filenameCochea1)
                
            MovCoche_1P2Mpa5()
    MovCoche_1P2Mpa5()

########################################
    ContMovCochesP1_3Mpa5 = 0
    def MovCoche_1P3Mpa5():
        """
        """
        global ContMovCochesP1_3Mpa5, d5, xmovecochebMpa5
        if(ContMovCochesP1_3Mpa5 < 360):
                
            d5.move(xmovecochebMpa5,0,30)

            ContMovCochesP1_3Mpa5 = ContMovCochesP1_3Mpa5 + 1
            d5.after(40,MovCoche_1P3Mpa5)

        else:

            ContMovCochesP1_3Mpa5 = 0
            d5.delete(xmovecochebMpa5)
            xmovecochebMpa5 = d5.create_image(360,-700,image=filenameCocheb1)
                
            MovCoche_1P3Mpa5()
    MovCoche_1P3Mpa5()
    

    
########################################
    ContMovCochesP1_4Mpa5 = 0
    def MovCoche_1P4Mpa5():
        """
        """
        global ContMovCochesP1_4Mpa5, d5, xmovecochea3Mpa5
        if(ContMovCochesP1_4Mpa5 < 400):
                
            d5.move(xmovecochea3Mpa5,0,30)

            ContMovCochesP1_4Mpa5 = ContMovCochesP1_4Mpa5 + 1
            d5.after(40,MovCoche_1P4Mpa5)

        else:

            ContMovCochesP1_4Mpa5 =0
            d5.delete(xmovecochea3Mpa5)
            xmovecochea3Mpa5 = d5.create_image(410,-1200,image=filenameCochea1)
                
            MovCoche_1P4Mpa5()
    MovCoche_1P4Mpa5()

########################################
    ContMovCochesP1_5Mpa5 = 0
    def MovCoche_1P5Mpa5():
        """
        """
        global ContMovCochesP1_5Mpa5, d5, xmovecochecMpa5
        if(ContMovCochesP1_5Mpa5 < 520):
                
            d5.move(xmovecochecMpa5,0,30)

            ContMovCochesP1_5Mpa5 = ContMovCochesP1_5Mpa5 + 1
            d5.after(40,MovCoche_1P5Mpa5)

        else:

            ContMovCochesP1_5Mpa5 =0
            d5.delete(xmovecochecMpa5)
            xmovecochecMpa5 = d5.create_image(380,-1200,image=filenameCochec1)
                
            MovCoche_1P5Mpa5()
    MovCoche_1P5Mpa5()
    
########################################
    ContMovCochesP1_6Mpa5 = 0
    def MovCoche_1P6Mpa5():
        """
        """
        global ContMovCochesP1_6Mpa5, d5, xmovecochea4Mpa5
        if(ContMovCochesP1_6Mpa5 < 400):
                
            d5.move(xmovecochea4Mpa5,0,30)

            ContMovCochesP1_6Mpa5 = ContMovCochesP1_6Mpa5 + 1
            d5.after(40,MovCoche_1P6Mpa5)

        else:

            ContMovCochesP1_6Mpa5 =0
            d5.delete(xmovecochea4Mpa5)
            xmovecochea4Mpa5 = d5.create_image(450,-1300,image=filenameCochea1)
                
            MovCoche_1P6Mpa5()
            
    MovCoche_1P6Mpa5()
    
########################################
    ContMovCochesP1_7Mpa5 = 0
    def MovCoche_1P7Mpa5():
        """
        """
        global ContMovCochesP1_7Mpa5, d5, xmovecochedMpa5
        if(ContMovCochesP1_7Mpa5 < 800):
                
            d5.move(xmovecochedMpa5,0,26)

            ContMovCochesP1_7Mpa5 = ContMovCochesP1_7Mpa5 + 1
            d5.after(40,MovCoche_1P7Mpa5)


        else:

            ContMovCochesP1_7Mpa5 =0
            d5.delete(xmovecochedMpa5)
            xmovecochedMpa5 = d5.create_image(426,-2000,image=filenameCoched1)
                
            MovCoche_1P7Mpa5()
    MovCoche_1P7Mpa5()
    


######################################################################################################################################



######################################################################################################################################

#Funcion para hacer mover los coches enemigos del jugador 2 del Mpa5
    ContMovCochesMpa5 = 0
    def MovCoche_2PMpa5():
        """
        """
        global ContMovCochesMpa5, d5, xmovecochea_Mpa5
        if(ContMovCochesMpa5 < 300):
                
            d5.move(xmovecochea_Mpa5,0,30)

            ContMovCochesMpa5 = ContMovCochesMpa5 + 1
            d5.after(40,MovCoche_2PMpa5)

        else:

            ContMovCochesMpa5=0
            d5.delete(xmovecochea_Mpa5)
            xmovecochea_Mpa5 = d5.create_image(1090,-100,image=filenameCochea1)
                
            MovCoche_2PMpa5()
    MovCoche_2PMpa5()
    
######################################     
    ContMovCoches1Mpa5 = 0

    def MovCoche_2P1Mpa5():
        """
        """
        global ContMovCoches1Mpa5, d5, xmovecochea_1Mpa5
        if(ContMovCoches1Mpa5 < 300):
                
            d5.move(xmovecochea_1Mpa5,0,30)

            ContMovCoches1Mpa5 = ContMovCoches1Mpa5 + 1
            d5.after(40,MovCoche_2P1Mpa5)

        else:

            ContMovCoches1Mpa5=0
            d5.delete(xmovecochea_1Mpa5)
            xmovecochea_1Mpa5 = d5.create_image(1110,-300,image=filenameCochea1)
                
            MovCoche_2P1Mpa5()
            
    MovCoche_2P1Mpa5()
    
######################################     
    ContMovCoches2Mpa5 = 0

    def MovCoche_2P2Mpa5():
        """
        """
        global ContMovCoches2Mpa5, d5, xmovecochea_2Mpa5
        if(ContMovCoches2Mpa5 < 360):
                
            d5.move(xmovecochea_2Mpa5,0,30)

            ContMovCoches2Mpa5 = ContMovCoches2Mpa5 + 1
            d5.after(40,MovCoche_2P2Mpa5)

        else:

            ContMovCoches2Mpa5=0
            d5.delete(xmovecochea_2Mpa5)
            xmovecochea_2Mpa5 = d5.create_image(1030,-500,image=filenameCochea1)
                
            MovCoche_2P2Mpa5()
            
    MovCoche_2P2Mpa5()



######################################     
    ContMovCoches3Mpa5 = 0

    def MovCoche_2P3Mpa5():
        """
        """
        global ContMovCoches3Mpa5, d5, xmovecocheb_Mpa5
        if(ContMovCoches3Mpa5 < 360):
            
            d5.move(xmovecocheb_Mpa5,0,30)

            ContMovCoches3Mpa5 = ContMovCoches3Mpa5 + 1
            d5.after(40,MovCoche_2P3Mpa5)

        else:

            ContMovCoches3Mpa5=0
            d5.delete(xmovecocheb_Mpa5)
            xmovecocheb_Mpa5 = d5.create_image(1150,-700,image=filenameCocheb1)

            MovCoche_2P3Mpa5()
            
    MovCoche_2P3Mpa5()



######################################     
    ContMovCoches4Mpa5 = 0

    def MovCoche_2P4Mpa5():
        """
        """
        global ContMovCoches4Mpa5, d5, xmovecochea_3Mpa5
        if(ContMovCoches4Mpa5 < 300):
            
            d5.move(xmovecochea_3Mpa5,0,30)

            ContMovCoches4Mpa5 = ContMovCoches4Mpa5 + 1
            d5.after(40,MovCoche_2P4Mpa5)

        else:

            ContMovCoches4Mpa5 = 0
            d5.delete(xmovecochea_3Mpa5)
            xmovecochea_3Mpa5 = d5.create_image(1115,-900,image=filenameCochea1)
            
            MovCoche_2P4Mpa5()
            
    MovCoche_2P4Mpa5()



######################################     
    ContMovCoches5Mpa5 = 0

    def MovCoche_2P5Mpa5():
        """
        """
        global ContMovCoches5Mpa5, d5, xmovecochec_Mpa5
        if(ContMovCoches5Mpa5 < 520):
            
            d5.move(xmovecochec_Mpa5,0,30)

            ContMovCoches5Mpa5 = ContMovCoches5Mpa5 + 1
            d5.after(40,MovCoche_2P5Mpa5)

        else:

            ContMovCoches5Mpa5=0
            
            d5.delete(xmovecochec_Mpa5)
            xmovecochec_Mpa5 = d5.create_image(1020,-1200,image=filenameCochec1)

            MovCoche_2P5Mpa5()

    MovCoche_2P5Mpa5()


######################################     
    ContMovCoches6Mpa5 = 0

    def MovCoche_2P6Mpa5():
        """
        """
        global ContMovCoches6Mpa5, d5, xmovecochea_4Mpa5
        if(ContMovCoches6Mpa5 < 400):
            
            d5.move(xmovecochea_4Mpa5,0,30)

            ContMovCoches6Mpa5 = ContMovCoches6Mpa5 + 1
            d5.after(40,MovCoche_2P6Mpa5)

        else:

            ContMovCoches6Mpa5=0
            d5.delete(xmovecochea_4Mpa5)
            xmovecochea_4Mpa5 = d5.create_image(1040,-1300,image=filenameCochea1)

            MovCoche_2P6Mpa5()
            
    MovCoche_2P6Mpa5()


######################################     
    ContMovCoches7Mpa5 = 0

    def MovCoche_2P7Mpa5():
        """
        """
        global ContMovCoches7Mpa5, d5, xmovecoched_Mpa5
        if(ContMovCoches7Mpa5 < 800):
            
            d5.move(xmovecoched_Mpa5,0,30)

            ContMovCoches7Mpa5 = ContMovCoches7Mpa5 + 1
            d5.after(40,MovCoche_2P7Mpa5)

        else:

            ContMovCoches7Mpa5 = 0
            d5.delete(xmovecoched_Mpa5)
            xmovecoched_Mpa5 = d5.create_image(1114,-2000,image=filenameCoched1)

            MovCoche_2P7Mpa5()
            
    MovCoche_2P7Mpa5()


######################################################################################################################################   
    
            
###################################
    d5.bind("<KeyPress>",key9)
    d5.bind("<KeyRelease>",key10)

    d5.focus_set()
    Puntuacion_1PMpa5()
    Puntuacion_2PMpa5()
    Velocidad_1PMpa5()
    Velocidad_2PMpa5()
    fuelMpa5()
    fuel2Mpa5()


    
    
################################### 



#Funcion para volver al menu Instrucciones

def backMenu():
    """
    """
    v7.destroy()
    v.deiconify()


    
def NuevaVentanaInstrucciones():
    global v7
    """
    """
    v7 = tkinter.Toplevel()
    v.iconify()
    v7.title("DODGE ROAD CARS")
    d6 = tkinter.Canvas(v7, width=1600, height=1600)
    Inst = tkinter.Label(v7,text="Dodge Road Cars es un juego de tipo arcade 2d de vista aerea en el cual deberas \n "
                                 "de ir avanzando esquivando a los coches enemigos y a los obstaculos a medida que vayas avanzando \n "
                                 "por el mapa. Al inicio del juego tu nivel de combustible iniciara en 100 puntos pero estos iran \n "
                                 "disminuyendo a medida que vayas avanzando en el, en la trayectoria tambien podras encontrar \n "
                                 "coches de bono que aumentaran tus puntos de combustible en 10 puntos, tu objetvo sera \n "
                                 "llegar a la meta antes de que se acaben tus puntos de gasolina.",font="ARIALBLACK",fg="white",bg="black")
    Backmenu = tkinter.Button(v7,text="Back",font="ARIALBLACK",fg="white",bg="Black",command=backMenu)

    # Carga una imagen
    
    x16 = d6.create_image(460,400,image=filename16)

    x17 = d6.create_image(1320,400,image=filename17)
    
    
    #Empaqueta (muestra) los widgets
    
    d6.pack()
    Inst.pack
    Inst.place(x=-6, y=270)
    Backmenu.pack()
    Backmenu.place(x=360, y=400)    
    
###################################

#Funcion para volver al menu Creditos

def backMenuCreditos():
    """
    """
    v8.destroy()
    v.deiconify()

    

def NuevaVentanaCreditos():
    global v8
    """
    """
    v8 = tkinter.Toplevel()
    v.iconify()
    v8.title("Dodge Road Cars")
    d7 = tkinter.Canvas(v8, width=1600, height=1600)
    Credits = tkinter.Label(v8,text="        Dodge Road Cars \n "
                                        "Producido y desarrollado por:\n"
                                        "David Alejandro Sanchez Arias\n"
                                "Estudiante de ingenieria de sistemas y computacion\n"
                                        "Pontificia universidad javeriana cali"   ,font="ARIALBLACK",fg="white",bg="black")
    BackmenuC = tkinter.Button(v8,text="Back",font="ARIALBLACK",fg="white",bg="Black",command=backMenuCreditos)

 # Carga una imagen
    
    x18 = d7.create_image(680,380,image=filename18)
    x19 = d7.create_image(560,380,image=filename19)

    
    #Empaqueta (muestra) los widgets
    d7.pack()
    Credits.pack
    Credits.place(x=80, y=270)
    BackmenuC.pack()
    BackmenuC.place(x=240, y=400)    


###################################


#Se crea la funcion para asociar el las funciones de movimiento del carro a las ventanas de los niveles
    
#Nivel 1
    
#Player 1
    
def key(event):
        """
        """
        global i,j,x2,d1
        tecla = repr(event.char)
        if(tecla == "'d'"):
            if(i < 71):
                d1.delete(x2)
                i = i + 10
                x2 = d1.create_image(414+i,630+j,image=filename2)
            else:
                d1.delete(x2)
                x2 = d1.create_image(414+i,630+j,image=filename2)
              
        if(tecla == "'a'"):
            if(i > -70):
                d1.delete(x2)
                i = i - 10
                x2 = d1.create_image(414+i,630+j,image=filename2)
            else:
                d1.delete(x2)
                x2 = d1.create_image(414+i,630+j,image=filename2)
                


#Player 2
    
def key2(event):
        """
        """
        global x3,z,a,d1
        tecla = repr(event.char)
        if(tecla == "'l'"):
            if(z < 80):
                d1.delete(x3)
                z = z + 10
                x3 = d1.create_image(1090+z,630+a,image=filename3)
            else:
                d1.delete(x3)
                x3 = d1.create_image(1090+z,630+a,image=filename3)
              
        if(tecla == "'j'"):
            if(z > -74):
                d1.delete(x3)
                z = z - 10
                x3 = d1.create_image(1090+z,630+a,image=filename3)
            else:
                d1.delete(x3)
                x3 = d1.create_image(1090+z,630+a,image=filename3)


###################################################################################
#Nivel 2

#Player 1
    
def key3(event):
        """
        """
        global x5,i,j,d2
        tecla = repr(event.char)
        if(tecla == "'d'"):
            if(i < 94):
                d2.delete(x5)
                i = i + 10
                x5 = d2.create_image(324+i,620+j,image=filename5)
            else:
                d2.delete(x5)
                x5 = d2.create_image(324+i,620+j,image=filename5)
              
        if(tecla == "'a'"):
            if(i > -94):
                d2.delete(x5)
                i = i - 10
                x5 = d2.create_image(324+i,620+j,image=filename5)
            else:
                d2.delete(x5)
                x5 = d2.create_image(324+i,620+j,image=filename5)
                


#Player 2
    
def key4(event):
        """
        """
        global x6,z,a,d2
        tecla = repr(event.char)
        if(tecla == "'l'"):
            if(z < 94):
                d2.delete(x6)
                z = z + 10
                x6 = d2.create_image(1002+z,620+a,image=filename6)
            else:
                d2.delete(x6)
                x6 = d2.create_image(1002+z,620+a,image=filename6)
              
        if(tecla == "'j'"):
            if(z > -94):
                d2.delete(x6)
                z = z - 10
                x6 = d2.create_image(1002+z,620+a,image=filename6)
            else:
                d2.delete(x6)
                x6 = d2.create_image(1002+z,620+a,image=filename6)


###################################################################################
#Nivel 3

#Player 1
    
def key5(event):
        """
        """
        global x8,i,j,d3
        tecla = repr(event.char)
        if(tecla == "'d'"):
            if(i < 44):
                d3.delete(x8)
                i = i + 10
                x8 = d3.create_image(262+i,620+j,image=filename8)
            else:
                d3.delete(x8)
                x8 = d3.create_image(262+i,620+j,image=filename8)
              
        if(tecla == "'a'"):
            if(i > -32):
                d3.delete(x8)
                i = i - 10
                x8 = d3.create_image(262+i,620+j,image=filename8)
            else:
                d3.delete(x8)
                x8 = d3.create_image(262+i,620+j,image=filename8)
                


#Player 2
    
def key6(event):
        """
        """
        global x9,z,a,d3
        tecla = repr(event.char)
        if(tecla == "'l'"):
            if(z < 44):
                d3.delete(x9)
                z = z + 10
                x9 = d3.create_image(930+z,620+a,image=filename9)
            else:
                d3.delete(x9)
                x9 = d3.create_image(930+z,620+a,image=filename9)
              
        if(tecla == "'j'"):
            if(z > -40):
                d3.delete(x9)
                z = z - 10
                x9 = d3.create_image(930+z,620+a,image=filename9)
            else:
                d3.delete(x9)
                x9 = d3.create_image(930+z,620+a,image=filename9)



###################################################################################
#Nivel 4

#Player 1
    
def key7(event):
        """
        """
        global x11,i,j,d4
        tecla = repr(event.char)
        if(tecla == "'d'"):
            if(i < 68):
                d4.delete(x11)
                i = i + 10
                x11 = d4.create_image(390+i,620+j,image=filename11)
            else:
                d4.delete(x11)
                x11 = d4.create_image(390+i,620+j,image=filename11)
              
        if(tecla == "'a'"):
            if(i > -60):
                d4.delete(x11)
                i = i - 10
                x11 = d4.create_image(390+i,620+j,image=filename11)
            else:
                d4.delete(x11)
                x11 = d4.create_image(390+i,620+j,image=filename11)
                


#Player 2
    
def key8(event):
        """
        """
        global x12,z,a,d4
        tecla = repr(event.char)
        if(tecla == "'l'"):
            if(z < 78):
                d4.delete(x12)
                z = z + 10
                x12 = d4.create_image(1060+z,620+a,image=filename12)
            else:
                d4.delete(x12)
                x12 = d4.create_image(1060+z,620+a,image=filename12)
              
        if(tecla == "'j'"):
            if(z > -60):
                d4.delete(x12)
                z = z - 10
                x12 = d4.create_image(1060+z,620+a,image=filename12)
            else:
                d4.delete(x12)
                x12 = d4.create_image(1060+z,620+a,image=filename12)


###################################################################################


#Se crea la funcion para asociar el las funciones de movimiento del carro a las ventanas de los niveles
    
#Nivel 5
    
#Player 1
    
def key9(event):
        """
        """
        global i,j,x14,d5
        tecla = repr(event.char)
        if(tecla == "'d'"):
            if(i < 71):
                d5.delete(x14)
                i = i + 10
                x14 = d5.create_image(414+i,630+j,image=filename14)
            else:
                d5.delete(x14)
                x14 = d5.create_image(414+i,630+j,image=filename14)
              
        if(tecla == "'a'"):
            if(i > -70):
                d5.delete(x14)
                i = i - 10
                x14 = d5.create_image(414+i,630+j,image=filename14)
            else:
                d5.delete(x14)
                x14 = d5.create_image(414+i,630+j,image=filename14)
                


#Player 2
    
def key10(event):
        """
        """
        global x15,z,a,d5
        tecla = repr(event.char)
        if(tecla == "'l'"):
            if(z < 80):
                d5.delete(x15)
                z = z + 10
                x15 = d5.create_image(1090+z,630+a,image=filename15)
            else:
                d5.delete(x15)
                x15 = d5.create_image(1090+z,630+a,image=filename15)
              
        if(tecla == "'j'"):
            if(z > -74):
                d5.delete(x15)
                z = z - 10
                x15 = d5.create_image(1090+z,630+a,image=filename15)
            else:
                d5.delete(x15)
                x15 = d5.create_image(1090+z,630+a,image=filename15)


###################################################################################

                
#Creo la funcion para asociar la imagen a el teclado
presiono = False
x = None
x1 = None
i = 0
j = 0
z = 0
a = 0

###################################################################################
def Exitgame():
    """
    """
    v.destroy()




# Crea los widgets
d = tkinter.Canvas(v, width=1000, height=1600)
c = tkinter.Label(v,text="DODGE ROAD CARS",font="ARIALBLACK",fg="red")
n1 = tkinter.Label(v,text="Nombre Jugador 1",bg="gray",font="ARIALBLACK",fg="lime")
n2 = tkinter.Label(v,text="Nombre Jugador 2",bg="gray",font="ARIALBLACK",fg="lime")
entrada = tkinter.StringVar()
entrada2 = tkinter.StringVar()
ct = tkinter.Entry(v,textvariable=entrada)
ct2 = tkinter.Entry(v,textvariable=entrada2)
lv1 = tkinter.Button(v,text="Nivel 1",bg="gray",font="ARIALBLACK",fg="lime",command = NuevaVentanaMpa1)
lv2 = tkinter.Button(v,text="Nivel 2",bg="gray",font="ARIALBLACK",fg="lime",command = NuevaVentanaMpa2)
lv3 = tkinter.Button(v,text="Nivel 3",bg="gray",font="ARIALBLACK",fg="lime",command = NuevaVentanaMpa3)
lv4 = tkinter.Button(v,text="Nivel 4",bg="gray",font="ARIALBLACK",fg="lime",command = NuevaVentanaMpa4)
lv5 = tkinter.Button(v,text="Nivel 5",bg="gray",font="ARIALBLACK",fg="lime",command = NuevaVentanaMpa5)
Salir = tkinter.Button(v,text = "Exit Game",bg="gray",font="ARIALBLACK",fg="lime",command = Exitgame)
Instrucciones = tkinter.Button(v,text = "Instrucciones",bg="gray",font="ARIALBLACK",fg="lime",command = NuevaVentanaInstrucciones)
Creditos = tkinter.Button(v,text = "Creditos",bg="gray",font="ARIALBLACK",fg="lime",command = NuevaVentanaCreditos)


# Carga una imagen
filename = tkinter.PhotoImage(file="412703.png")
x = d.create_image(500,340,image=filename)

#filename = tkinter.PhotoImage(file="321.png")
#x = d.create_image(580,360,image=filename)

# Carga las imagenes del juego

# Mpa1
filename1 = tkinter.PhotoImage(file="MMp1.png")

filenameMove = tkinter.PhotoImage(file="FondoMovePs.png")
filenameMove2 = tkinter.PhotoImage(file="FondoMovePs.png")

#Mis Coches
filename2 = tkinter.PhotoImage(file="MiCoche.png")


filename3 = tkinter.PhotoImage(file="MiCoche2.png")

#Coches Enemigos
filenameCochea = tkinter.PhotoImage(file="Cochea.png")
filenameCocheb = tkinter.PhotoImage(file="Cocheb.png")
filenameCochec = tkinter.PhotoImage(file="Cochec.png")


#Coche de bono
filenameCoched = tkinter.PhotoImage(file="Coched.png")

# Mpa2
filename4 = tkinter.PhotoImage(file="MMp2.png")

filenameMoveMpa2 = tkinter.PhotoImage(file="FondoMove2Ps.png")
filenameMove2Mpa2 = tkinter.PhotoImage(file="FondoMove2Ps.png")

filename5 = tkinter.PhotoImage(file="MiCoche.png")


filename6 = tkinter.PhotoImage(file="MiCoche2.png")

#Mpa3
filename7 = tkinter.PhotoImage(file="MMp3.png")

filenameMoveMpa3 = tkinter.PhotoImage(file="FondoMove3Ps.png")
filenameMove2Mpa3 = tkinter.PhotoImage(file="FondoMove3Ps.png")

filename8 = tkinter.PhotoImage(file="MiCoche.png")


filename9 = tkinter.PhotoImage(file="MiCoche2.png")

#Mpa4
filename10 = tkinter.PhotoImage(file="MMp4.png")

filenameMoveMpa4 = tkinter.PhotoImage(file="FondoMove4Ps.png")
filenameMove2Mpa4 = tkinter.PhotoImage(file="FondoMove4Ps.png")

filename11 = tkinter.PhotoImage(file="MiCoche.png")


filename12 = tkinter.PhotoImage(file="MiCoche2.png")

#Mpa5
filename13 = tkinter.PhotoImage(file="MMp5.png")

filenameMoveMpa5 = tkinter.PhotoImage(file="FondoMove5Ps.png")
filenameMove2Mpa5 = tkinter.PhotoImage(file="FondoMove5Ps.png")

filename14 = tkinter.PhotoImage(file="MiCocheMpa5.png")


filename15 = tkinter.PhotoImage(file="MiCoche2Mpa5.png")


#Coches Enemigos
filenameCochea1 = tkinter.PhotoImage(file="Cochea1.png")
filenameCocheb1 = tkinter.PhotoImage(file="Cocheb1.png")
filenameCochec1 = tkinter.PhotoImage(file="Cochec1.png")



#Coche de bono
filenameCoched1 = tkinter.PhotoImage(file="Coched1.png")


#Instrucciones
filename16 = tkinter.PhotoImage(file="SD.png")

filename17 = tkinter.PhotoImage(file="interfazi3Sf.png")

#Creditos
filename18 = tkinter.PhotoImage(file="SD2I.png")
filename19 = tkinter.PhotoImage(file="SD2B.png")






# Empaqueta (muestra) los widgets

c.pack()
c.place(x=420, y=0)
n1.pack()
n1.place(x=60, y=200)

n2.pack()
n2.place(x=60, y=300)

d.pack()

ct.pack()
ct.place(x=200, y =200)

ct2.pack()
ct2.place(x= 200, y=300)

lv1.pack()
lv1.place(x=60, y=400)

lv2.pack()
lv2.place(x=140, y=400)

lv3.pack()
lv3.place(x=220, y=400)

lv4.pack()
lv4.place(x=300, y=400)

lv5.pack()
lv5.place(x=380, y=400)

Salir.pack()
Salir.place(x=60, y=600)

Instrucciones.pack()
Instrucciones.place(x=200,y=600)

Creditos.pack()
Creditos.place(x=380, y=600)


     
# Pone el foco en el canvas
##d.focus_set()

# Ciclo para escuchar los eventos
v.mainloop()
